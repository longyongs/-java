package kr.or.shi.singlelinkedlist;


//09.01 2-1
public class SingleLinkedList<T> {
	public Node<T> head = null;
	
	public class Node<T> {
		T data;
		Node<T> next = null;
		
		//생성자
		public Node(T data) {
			this.data = data;
		}
	}
	
	public void addNode(T data) {
		if(head == null) {
			head = new Node<>(data);
		}
		else {
			Node<T> node = this.head;
			while(node.next != null) {			//그 다음 노드가 있음.
				node = node.next;
			}
			
			node.next = new Node<>(data);
		}
	}
	
	public void printAll() {
		if(head != null) {
			Node<T> node = this.head;			//노드는 헤더에서 시작함
			System.out.println(node.data);
			
			while(node.next != null) {
				node = node.next;
				System.out.println(node.data);
			}
		}
	}
	
	public Node<T> search(T data) {
		if(this.head == null) {			//링크드 리스트에 노드가 없는 경우
			return null;
		}
		else {
			Node<T> node = this.head;		//head부터 시작함
			
			while(node != null) {			//순회하면서 해당 노드 찾음
				if(node.data == data) {
					return node;			//해당 노드 리턴
				}
				else {
					node = node.next;		//찾는 노드가 아니라면 다음 노드로 찾음
				}
			}
			return null;
			
		}
	}
	
	//중간에 데이터를 추가하는 경우
	public void addNodeInside(T data, T isData) {	//추가할 노드, T data 앞에 있는 노드
		Node<T> searchedNode = this.search(isData);
		
		if(searchedNode == null) {
			this.addNode(data);
		}
		else {
			Node<T> nextNode = searchedNode.next;
			searchedNode.next = new Node<>(data);
			searchedNode.next.next = nextNode;
		}
	}
	
	
	public static void main(String[] args) {
		SingleLinkedList<Integer> myLinkedList = new SingleLinkedList<>();
		myLinkedList.addNode(1);
		
		System.out.println(myLinkedList.head.data);
		System.out.println(myLinkedList.head.next);			
		
		myLinkedList.addNode(2);
		System.out.println(myLinkedList.head.next);			
		System.out.println(myLinkedList.head.next.data);			
		
		myLinkedList.addNode(3);
		myLinkedList.addNode(4);
		myLinkedList.addNode(5);
		myLinkedList.printAll();
		System.out.println();
		
		myLinkedList.addNodeInside(5, 1);		//1뒤에 5
		myLinkedList.printAll();
		System.out.println();
		
		myLinkedList.addNodeInside(6, 3);
		myLinkedList.printAll();
		System.out.println();

		myLinkedList.addNodeInside(7, 20);
		myLinkedList.printAll();

	}
}
