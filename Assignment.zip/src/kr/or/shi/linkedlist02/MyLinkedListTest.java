package kr.or.shi.linkedlist02;
//09.01 3-3
public class MyLinkedListTest {

	public static void main(String[] args) {
		MyLinkedList list = new MyLinkedList();
		list.addElement("A");
		list.addElement("B");
		list.addElement("C");
		list.printAll();
		
//		list.insertElement(2, "d");
//		list.printAll();

	}
}
