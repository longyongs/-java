package kr.or.shi.linkedlist02;
//09.01 3-1
//다음과 같이 LinkedList 자체를 구현하시오.
//아래 UML 그림을 참조하여 클래스를 생성하고 그 아래 처럼 실행하고 출력결과가 나오게 하시오.
//연결리스트는 각 노드가 데이터와 포인터를 가지고 한 줄로 연결되어 있는 방식의 자료구조
//- 노드(Node) : 데이터 저장 단위(데이터값, 포인터)로 구성
//- 포인터(pointer) : 각 노드안에서 다음이나 이전의 노드와의 연결 정보를 가지고 있는 공간
public class MyListNode {
	private String data;			//자료, 							잠금이라 private
	MyListNode next;				//다음 노드를 가리키는 링크
	
	public MyListNode() {			//기본생성자
		data = null;				//처음에는 데이터없다. 초기화하는 생성자
		next = null;
	}
	
	public MyListNode(String data) {	//오버로드된 생성자
		this.data=data;					//객체생성
		next = null;		
	}
		
	public String getData() {
		return data;
	}
}
