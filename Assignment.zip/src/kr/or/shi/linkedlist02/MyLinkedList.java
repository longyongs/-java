package kr.or.shi.linkedlist02;
//09.01 3-2
//다음과 같이 LinkedList 자체를 구현하시오.
//아래 UML 그림을 참조하여 클래스를 생성하고 그 아래 처럼 실행하고 출력결과가 나오게 하시오.
//연결리스트는 각 노드가 데이터와 포인터를 가지고 한 줄로 연결되어 있는 방식의 자료구조
//- 노드(Node) : 데이터 저장 단위(데이터값, 포인터)로 구성
//- 포인터(pointer) : 각 노드안에서 다음이나 이전의 노드와의 연결 정보를 가지고 있는 공간
public class MyLinkedList {
	
	private MyListNode head;	//멤버들
	int count;					//배열늘려주는건가?
	
	public MyLinkedList() {		//기본생성자
		head = null;			//멤버에대해서 초기화
		count = 0;
	}
	
	public MyListNode addElement(String data) {
		MyListNode newNode;
		
		if(head == null) {					//맨 처음일때
			newNode = new MyListNode(data);
			head = newNode;
		}
		else {
			newNode = new MyListNode(data);
			MyListNode temp = head;
			while(temp.next != null) {		//맨뒤에 가서
				temp = temp.next;
			}
			temp.next = newNode;
		}
		count++;
		return newNode;
	}
	
	public MyLinkedList() insertElement
	
	public void printAll() {
		if(count == 0) {
			System.out.println("출력할 데이터가 없습니다.");
			return;
		}
		
		MyListNode temp = head;
		while(temp != null) {
			System.out.print(temp.getData());
			temp = temp.next;
			if(temp != null) {
				System.out.print("->");
			}
		}
		System.out.println("");
 	}
	
}
