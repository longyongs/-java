package kr.or.shi.io;
//21.09.07 1-1

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;


public class WordSearch {
	 
	public static void main(String[] args) {
		//단어 찾기 프로그램
		
		//단어를 저장할 장소 생성
		List<String> vector = new Vector<>();
		File file = new File("words.txt");
		System.out.println("파일 크기 : " + file.length()/1024 + "kb");
		
		try {
			Scanner fscan = new Scanner(file);
			
			while(fscan.hasNext()) {
				vector.add(fscan.next());
			}
			
			fscan.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		
		}
		
		//단어검색하기
		Scanner scan = new Scanner(System.in);
		while(true) {
			boolean found = false;
			System.out.println("찾을 단어 입력(종료는 exit) >> ");
			String search = scan.next();
			
			//검색종료코드
			if(search.equals("exit")) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}
		
			for(int i=0; i<vector.size(); i++) {
				String vs = vector.get(i);		//벡터내의 문자열을 가져옴.
				if(search.equals(vs)) {
					System.out.println("찾은 문자 : " + vs);
					found = true;
				}
			}
		
			if(!found) {
				System.out.println("찾는 단어가 없습니다.");
			}
			
		}
		
		
		
		
		scan.close();
	}
}

	
