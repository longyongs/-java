package kr.or.shi.array;


//08.31 1-1

public class MyArray {
	
	int[] intArr;			//int 배열 (o = default)
	int count;				//개수 	 (자물쇠 열리면 = public)

	public int ARRAY_SIZE;	//
	public static final int ERROR_NUM = -99999999;	//1이 아닌 값
	
	//생성자
	public MyArray() {
		count = 0;
		ARRAY_SIZE = 10;
		intArr = new int[ARRAY_SIZE];		//사이즈 10개짜리
	}
	
	public MyArray(int size) {				//내가 지정한 수만큼 배열 사이즈 할당
		count = 0;
		ARRAY_SIZE = 10;
		intArr = new int[ARRAY_SIZE];
	}
	
	//메서드
	public void addElement(int num) {
		if(count >= ARRAY_SIZE) {
			System.out.println("메모리 공간이 충분하지 않습니다.");
			return;
		}
		intArr[count++] = num;
	}

	public void printAll() {
		if(count == 0) {
			System.out.println("출력할 내용이 없습니다.");
			return;
		}
		
		for(int i=0; i<count; i++) {
			System.out.println(intArr[i]);
		}
	}
	
	public void insertElement(int position, int num) {
		int i;
		
		if(count >= ARRAY_SIZE) {		//예외처리
			System.out.println("메모리 공간이 충분하지 않습니다.");
			return;
		}
		
		if(position < 0 || position > count) { //예외처리 해당된 크기보다 작거나 큰경우
			System.out.println("insert 에러입니다.");
			return;
		}
		
		for(i = count-1; i>=position; i--) {	//0부터 시작해서 이동
			intArr[i+1] = intArr[i];
		}
		
		intArr[position] = num;
		count++;
	}
	
	public boolean isEmpty() {
		if(count == 0) 
			return true;
		else
			return false;
	}
	
	public int removeElement(int position) {
		
		int result = ERROR_NUM;
		
		if(isEmpty()) {
			System.out.println("아무값도 없습니다.");
			return result;
		}
		
		if(position < 0 || position >= count) {
			System.out.println("삭제 오류입니다.");
			return result;
		}
		
		result = intArr[position];
		
		for(int i=position; i<count-1; i++) {
			intArr[i] = intArr[i+1];
		}
		
		count--;
		
		return result;
	}

	public void removeAll() {
		for(int i=0; i<count; i++) {
			intArr[i] = 0;
		}
		count = 0;
	}
	
	public int getElement(int position) {
		
		if(position < 0 || position > count-1) {
			System.out.println("해당 위치값이 존재 않습니다.");
			return ERROR_NUM;
					
		}
		
		return intArr[position];
	}
	
	public int getSize() {
		return count;
	}
	
}	

	
	

