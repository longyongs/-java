package kr.or.shi.singleton;
//21.09.08 1-3
/*
* 카드 회사가 있습니다.
* 카드회사는 유일한 객체이고, 이 회사에서는 카드를 발급하면 항상 고유번호가 자동으로 생성됩니다.
* 20211216부터 시작하여 카드가 생성될 때마다 20211217, 20211218식으로 증가 됩니다.
* 다음코드가 수행되도록 Card 클래스와 CardCompany 클래스를 구현하세요.
* 아래 내용 참조해서 구현하세요.
*/


public class CardCompanyTest {
	
	public static void main(String[] args) {
		CardCompany company = CardCompany.getInstance();	//싱글톤 패턴
		
		Card myCard = company.createCard();					//메서드에서 Card 생성
		Card yourCard = company.createCard();
		
		System.out.println(myCard.getCardNumber()); 		//20211217 출력
		System.out.println(yourCard.getCardNumber()); 		//20211218 출력
	}
}
