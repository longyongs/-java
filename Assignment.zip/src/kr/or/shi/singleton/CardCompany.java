package kr.or.shi.singleton;
//21.09.08 1-1
/*
 * 카드 회사가 있습니다.
 * 카드회사는 유일한 객체이고, 이 회사에서는 카드를 발급하면 항상 고유번호가 자동으로 생성됩니다.
 * 20211216부터 시작하여 카드가 생성될 때마다 20211217, 20211218식으로 증가 됩니다.
 * 다음코드가 수행되도록 Card 클래스와 CardCompany 클래스를 구현하세요.
 * 아래 내용 참조해서 구현하세요.
 */
public class CardCompany {
	
	private static CardCompany singleton = new CardCompany();  
	static CardCompany instance;
	
	private CardCompany() {}
	
	public static Card createCard() {
		Card card = new Card();
		return card;
	}
	
	
	public static CardCompany getInstance() {
		if (singleton == null) {
			singleton = new CardCompany();
		}
		return singleton;
	}


}
