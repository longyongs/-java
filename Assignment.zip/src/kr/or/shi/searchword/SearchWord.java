package kr.or.shi.searchword;
//21.09.07 1-1

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Vector;


public class SearchWord {
	 
	public static void main(String[] args) {
		
		Vector<String> vector = new Vector<>();	
		Scanner scanner = new Scanner(System.in);
		
		try(InputStreamReader isr = new InputStreamReader(new FileInputStream("works.txt"))) {
	}
}
