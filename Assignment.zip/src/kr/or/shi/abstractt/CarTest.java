package kr.or.shi.abstractt;

import java.util.ArrayList;

public class CarTest {

	public static void main(String[] args) {
		//객체생성
		ArrayList<Car> carList = new ArrayList<>();
		carList.add(new Avante());
		carList.add(new Grandeur());
		carList.add(new Genesis());
		carList.add(new Sonata());
		
		//향상된 for문
		for(Car car : carList) {
			car.run();
			System.out.println("=====================================");
		}
	}
}
