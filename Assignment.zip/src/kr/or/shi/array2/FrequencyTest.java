package kr.or.shi.array2;
//08.31 2-1

public class FrequencyTest {
	
	public static void main(String[] args) {
		
		int[] target = { 1, 3, 3, 2, 1, 1, 3, 0, 1, 2};
		
		//target 배열내 숫자가 배열(arr)의 인덱스로 적용해서 해당 인덱스의 요소 값을 1씩 증가시킨다.
		int[] arr = new int[4];		//0,1,2,3 
		
		for(int i=0; i<target.length; i++) 
			arr[target[i]]++;
		
		for(int i=0; i<arr.length; i++)
			System.out.println(i + "번 숫자 --> " + arr[i] + "회");
		
		
//		int[] arr2 = new int[] { 1, 3, 3, 2, 1, 1, 3, 0, 1, 2};
//		int count = 0;
//		int[] arr1 = new int[] {1, 2, 3, 4};	
//		for(int i=0; i<arr1.length; i++) {
//			for(int j=0; j<arr2.length; j++)
//			if(arr2[j] == arr1[i]) {
//				count++;
//			}
//			System.out.println(i + "번 숫자 -->" + count + "회");
//		}
		
	}
	
}


