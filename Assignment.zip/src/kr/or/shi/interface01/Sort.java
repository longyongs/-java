package kr.or.shi.interface01;
//08.30 1-1
//교수님 풀이
public interface Sort {
	public void ascending(int[] arr);			//오름차순
	public void descending(int[] arr);			//내렴차순
	
	default void description() {
		System.out.println("숫자를 정렬하는 알고리즘입니다.");
	}
}
