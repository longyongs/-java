package kr.or.shi.abstractt02;
//1-5
public class Player {
	
	private PlayerLevel level;
	
	public Player() {
		level = new BeginnerLevel();	//객체생성
		level.showLevelMessage();		//출력
	}
	
	public void upgradeLevel(PlayerLevel level) { //객체생성
		this.level = level;							//초기화
		level.showLevelMessage(); 					//출력
	}
	
	public void play(int count) {
		level.go(count);							//*중요*
	}
	
}
