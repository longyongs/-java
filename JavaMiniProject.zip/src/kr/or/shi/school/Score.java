package kr.or.shi.school;
//21.09.09 1-3


public class Score {
	
	private int studentId;				//학번
	private Subject subject;			//과목
	private int score;					//점수
	
	public Score(int studentId, Subject subject, int score) {
		this.studentId = studentId;
		this.subject = subject;
		this.score = score;
	}
	
	//값을 확인하기 위한 getter
	public int getStudentId() {
		return studentId;
	}

	public Subject getSubject() {
		return subject;
	}

	public int getScore() {
		return score;
	}
	
	
	
}
