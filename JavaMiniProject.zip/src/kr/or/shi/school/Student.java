package kr.or.shi.school;
//21.09.09 1-2

import java.util.ArrayList;


public class Student {
	
	private int studentId;			//학번
	private String studentName;		//이름
	private Subject majorSubject;	//전공과목
	private ArrayList<Score> scores = new ArrayList<>();		//학생의 성적리스트

	//생성자 추가 source -> Generic Construct using field
	public Student(int studentId, String studentName, Subject majorSubject) {
		//super(); //없어도 자동으로 만들어짐.
		this.studentId = studentId;
		this.studentName = studentName;
		this.majorSubject = majorSubject;
	}
	
	
	//과목 점수를 컬렉션에 추가함
	public void addSubjectScore(Score score) {
		scores.add(score);
	}

	// getter
	public int getStudentId() {
		return studentId;
	}


	public String getStudentName() {
		return studentName;
	}


	public Subject getMajorSubject() {
		return majorSubject;
	}

	
	public ArrayList<Score> getScores() {
		return scores;
	}
	
	
	
}
