package kr.or.shi.grade;
//21.09.09 3-3

//전공 과목 학점에 대한 클래스

public class MajorEvaluation implements GradeEvaluation {
	
	public MajorEvaluation() {
		
	}
	
	//add method
	@Override
	public String getGrade(int score) {

		String grade;		//지역변수라 초기화 안됨.
		
		if (score >= 95 && score <=100)
			grade = "S";
		else if (score >= 90 && score <=94)
			grade = "A";
		else if (score >= 80 && score <=89)
			grade = "B";
		else if (score >= 70 && score <=79)
			grade = "C";
		else if (score >= 60 && score <=69)
			grade = "D";
		else
			grade = "F";
		
		return grade;
	}



}
