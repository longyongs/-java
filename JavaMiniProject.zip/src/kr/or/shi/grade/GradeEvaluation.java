package kr.or.shi.grade;
//21.09.09 3-1

public interface GradeEvaluation {
	
	public String getGrade(int score);
}
