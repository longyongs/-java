package kr.or.shi.array;

public class ArrayTest01 {

	public static void main(String[] args) {
		
		//score 참조변수임. 데이터 타입은 int[]임
		int[] score = null;
		//메모리 할당이 않되었는데, 값을 대입하고 있음(문법에러)
		//score = {100, 200};
		
		//score는 5개의 메모리 공간을 heap에다가 생성을 하고있음.(20바이트)
		score = new int[5];
		
		//배열명이 곧 주소임.
		System.out.println("score의 주소값 : " + score);
		
		for(int i=0; i<score.length; i++) {
			System.out.println("score[" +i+ "] = " + score[i]);
		}
		System.out.println();
		
		//score[0]는 변수와 동일함.
		//score는 주소임. []안에 들어가는 숫자를 인덱스(첨자)라고 함. -> 위치정보이다 배열의 몇번쨰이다
		score[0] = 100; 
		for(int i=0; i<score.length; i++) {
			System.out.println("score[" +i+ "] = " + score[i]);
		}
		System.out.println();
		
		//score[0] = 10,	..... score[4] = 14
		for(int i=0; i<score.length; i++) {
			score[i] = 10 + i;
		}
		
		//배열의 각각의 방에 있는 값을 출격하는 형태
		for(int i=0; i<score.length; i++) {
			score[i] = 10 + i;
			System.out.println("score[" +i+ "] = " + score[i]);

		
		}
		
	}
}


