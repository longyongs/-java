package kr.or.shi.array;

import java.util.Arrays;

public class ArrayTest03 {

	public static void main(String[] args) {
		
		//40바이트가 힙에 생성됨
		int[] arr1 = new int[10];
		
		//1~100사이의 임의의 정수가 출력
		for(int i=0; i<arr1.length; i++) {
			arr1[i] = (int)(Math.random() * 10) + 1;
		}
		
		for(int i=0; i<arr1.length; i++) {
			if(i != 9) {
				System.out.print(arr1 [i] + ", ");
			}
			else {
				System.out.println(arr1[i]);
			}
		}
		System.out.println();
		
		
		//Arrays클래스는 배열을 조작하기 쉽게 만들어 놓은 유틸리티 클래스
		System.out.println(Arrays.toString(arr1));
		System.out.println();
		
		//6바이트가 힙에 생성됨.
		// a b c로 출력
		char[] chArr = new char[] {'a', 'b', 'c'};
		System.out.println(Arrays.toString(chArr));
		
		String[] str = new String[10];
		boolean[] bool = new boolean[10];
		
		System.out.println(arr1);				//주소값 출력
		System.out.println(arr1.toString());	//주소값
		
		System.out.println(str);				//자바타입+주소값
		System.out.println(bool);				//주소값	
		
		
		//char타입은(만) 주소를 출력할려면 toString() 호출해야 함.
		System.out.println(chArr);				//예외적으로 주소번지가 가르키는 곳에 있는 값을 출력.
		System.out.println(chArr.toString());	// 주소값 출력
	
		
	}

}
