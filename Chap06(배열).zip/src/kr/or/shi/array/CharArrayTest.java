package kr.or.shi.array;

public class CharArrayTest {

	public static void main(String[] args) {
		
		char[] alpahbets = new char[26];
		char ch = 'A';
		
		
		//A,65
		//B, 66
		//...... z,90
		
		for(int i=0; i<alpahbets.length; i++) {
			alpahbets[i] = ch++;
			
		}
		
		for(int i=0; i<alpahbets.length; i++) {
			System.out.println(alpahbets[i] +", " + (int)alpahbets[i]);
		}
	
	}

}
