package kr.or.shi.array3;

public class StringArrayTest2 {

	public static void main(String[] args) {
		String[] province = new String[3];		//1차원 배열인데 메모리 형태 그림은 앞 예제처럼 
		//String 1차원 배열 -> 3개의 문자열을 담을 수 있는 배열 생성함		
		//String 타입의 참조 변수 3개를 저장하기 위한 공간 생성 -> 이때.			  
		//참조형 변수 각 요소 기본값이 null로 초기화.							   주소번지 
		System.out.println(province[0]);						// ㅁ -> ㅁ (null)
		System.out.println(province[1]);						//   -> ㅁ (null)
		System.out.println(province[2]);						//   -> ㅁ (null)

	}

}
