package kr.or.shi.grade;

public interface GradeEvaluation {
	
	public String getGrade(int score);

}
