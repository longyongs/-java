package kr.or.shi.utils;

public class Constant {
	
	public static final int AB_TYPE = 0;		//A,B,C,D,F 학점
	public static final int SAB_TYPE = 1;		//S,A,B,C,D,F 학점
	
	public static final int OPERATING_SYSTEM = 1001;		//운영체제
	public static final int MATH = 1002;					//수학
	

}
