package kr.or.shi.decision2;

public class SwitchTest {

	public static void main(String[] args) {
		
		int score = 95;
		
		//조건 : int 이하의 정수값, String값이 들어옴. 조건을 잘 줘야함.
		switch(score) {
			case 95 :
				System.out.println("95점 입니다");
				break;
			case 94 :
				System.out.println("94점 입니다");
				break;
			case 93 :
				System.out.println("93점 입니다");
				break;
			default :									//해당되는 값이 없는 경우 출력
				System.out.println("잘못된 값입니다.");
		
		}
	}

}
