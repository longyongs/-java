package kr.or.shi.jang;

import java.util.Scanner;

public class DecisionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// -> 프로그램 자체를 종료시킴.
		// switch는 10의 배수 나머지는 if else if로 중첩시켜서 다시
		
		Scanner scan = new Scanner(System.in);

		System.out.print("자신의 연령대를 입력하세요 : ");
		int age = scan.nextInt();
		
			switch(age) {
			case 10:
				System.out.println( age + "대입니다. 참고서 코너는 A구역입니다."); 
				break;
			case 20:
				System.out.println( age + "대입니다. 취업서적 코너는 B구역입니다."); 
				break;
			case 30:
				System.out.println( age + "대입니다. 자기 개발 코너는 C구역입니다."); 
				break;
			case 40:
				System.out.println( age + "대입니다. 재테크 코너는 D구역입니다.");
				break;
			case 50:
				System.out.println( age + "대입니다. 재취업 코너는 E구역입니다."); 
				break;
			default:
				if(age >= 10 && age < 20) { 
					System.out.println("10이라고 다시 연령대를 입력해주세요. 프로그램을 종료합니다.");
				} 
				else if(age >= 20 && age < 30) {
					System.out.println("20이라고 다시 연령대를 입력해주세요. 프로그램을 종료합니다.");
				} 
				else if(age >= 30 && age < 40) { 
					System.out.println("30이라고 다시 연령대를 입력해주세요. 프로그램을 종료합니다.");
				}
				else if(age >= 40 && age < 50) { 
					System.out.println("40이라고 다시 연령대를 입력해주세요. 프로그램을 종료합니다."); 
				} 
				else if(age >= 50 && age < 60) {
					System.out.println("50이라고 다시 연령대를 입력해주세요. 프로그램을 종료합니다.");
				} 
				else if(age >= 60) {
					System.out.println("60대 이상입니다. 건강/장수 코너는 F구역입니다."); 
				} 
				else {
					System.out.println("최소 10 이상만 입력해주세요. 프로그램을 종료합니다 ."); //10세미만 아동
					
				}
				System.exit(0); 
			}	
		scan.close();
	}

}
