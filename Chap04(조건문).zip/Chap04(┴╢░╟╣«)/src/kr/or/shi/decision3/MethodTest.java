package kr.or.shi.decision3;

public class MethodTest {
	
	/*
	 * 메서드 선언부 구성 ( public/protected/default/private은 접근지정자, static은 )
	 * 1. 리턴타입(반환값) : int
	 * 2. 메서드명
	 * 3. () : 매개변수, 인자값, Arguments, parameter
	 * 
	 * 메서드 구현부(정의부) : { } 
	 */
	public static int add(int x, int y) {					//메서드
		System.out.println("add 메서드 호출함");
		int temp = x + y;
		return temp;
	}	
	
	public static int sub(int x1, int y1) {
		System.out.println("sub 메서드 호출함");
		return x1 - y1;
	}
	
	public static void main(String[] args) {
		
		int num1 = 10;
		int num2 = 30;
		
		//값에 의한 복사 (Call by value)
		int result = add(num1, num2);
		System.out.println("num1 + num2 : " + result);
		
		result = sub(num1, num2);
		System.out.println("num1 - num2 : " + result);
		
	}
	
}
