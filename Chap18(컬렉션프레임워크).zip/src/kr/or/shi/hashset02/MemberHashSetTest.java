package kr.or.shi.hashset02;
//2-3
import java.util.Iterator;

import kr.or.shi.vector.Board;

//2-3
public class MemberHashSetTest {
	
	public static void main(String[] args) {
		MemberHashSet memberHashSet = new MemberHashSet();
		
		Member memberLee = new Member(1001, "이순신");
		Member memberRuy = new Member(1002, "류현진");
		Member memberChoi = new Member(1003, "최지만");
		Member memberKim = new Member(1004, "김하성");
		Member memberKim2 = new Member(1004, "김하성");
		
		memberHashSet.addMember(memberLee);
		memberHashSet.addMember(memberRuy);
		memberHashSet.addMember(memberChoi);
		memberHashSet.addMember(memberKim);
		memberHashSet.addMember(memberKim2);
		
		
		memberHashSet.showAllMember();
		
		memberHashSet.removeMember(memberRuy.getMemberId());
		memberHashSet.showAllMember();
		
		
		}
	
	}

