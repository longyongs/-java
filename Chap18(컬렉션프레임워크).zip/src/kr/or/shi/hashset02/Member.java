package kr.or.shi.hashset02;
//21.09.02 2-1

public class Member {
	private int memberId;
	private String memberName;
	
	public Member(int memberId, String memberName) {
		super();
		this.memberId = memberId;
		this.memberName = memberName;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	
	@Override
	public String toString() {
		return this.getMemberName() + "회원님의 아이디는 " + this.getMemberId() + "입니다.";
	}
	
	//논리적 동등적용 (같은 값이면 걸러주는 부분인듯)  
	@Override
	public int hashCode() {
		
		return memberId;
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof Member) {
			Member member = (Member)obj;
			if(this.memberId == member.memberId) {
				return true;
			}
			else {
				return false;
			}
		}
		
		
		return false;
	}
	
}
