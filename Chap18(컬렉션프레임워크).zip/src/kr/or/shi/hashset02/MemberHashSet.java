package kr.or.shi.hashset02;
//2-2
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import kr.or.shi.vector.Board;

public class MemberHashSet {
	private HashSet<Member> hashSet;
	
	public MemberHashSet() {			//기본생성자
		hashSet = new HashSet<>();
	}
	
	public MemberHashSet(int size) {
		hashSet = new HashSet<>(size);
	}
	
	public void addMember(Member member) {
		hashSet.add(member);
	}
	
	public void showAllMember() {
		for(Member member : hashSet) {
			System.out.println(member);
		}
		System.out.println();
	}
	
	public boolean removeMember(int memberId) {

		Iterator<Member> iterator = hashSet.iterator();
		while(iterator.hasNext()) {						//가져올 데이터 있는지 접근
			Member member = iterator.next();				//있으면 가져옴
			int tempId = member.getMemberId();
			
			if(tempId == memberId) {
				hashSet.remove(member);
				return true;
			}
		}
		
		System.out.println(memberId + "가 존재하지 않습니다.");
		return false;
		}
	}

