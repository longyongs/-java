package kr.or.shi.vector;

import java.util.Scanner;
import java.util.Vector;

public class VertorBig {
 
	public static void printBig(Vector<Integer> vector) {
		
		int big = vector.get(0);
		for(int i=1; i<vector.size(); i++) {
			if(big < vector.get(i)) {
				big = vector.get(i);
			}
		}
		
		System.out.println("가장 큰수는 " + big);
	} 
	    
	
	public static void main(String[] args) {
		
		Vector<Integer> vector = new Vector<>();
		System.out.print("정수(-1이 입력될 때까지)>>");
		
		Scanner scanner = new Scanner(System.in);
		while(true) {
			int n = scanner.nextInt();
			if(n==-1) {
				break;
			}
			vector.add(n);
		}
		
		
		printBig(vector);
		scanner.close();
	}
}
