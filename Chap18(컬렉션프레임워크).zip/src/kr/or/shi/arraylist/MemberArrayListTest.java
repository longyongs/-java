package kr.or.shi.arraylist;
//2-3
import java.util.Iterator;

import kr.or.shi.vector.Board;

//2-3
public class MemberArrayListTest {
	
	public static void main(String[] args) {
		MemberArrayList memberArrayList = new MemberArrayList();
		
		Member memberLee = new Member(1001, "이순신");
		Member memberRuy = new Member(1002, "류현진");
		Member memberChoi = new Member(1003, "최지만");
		Member memberKim = new Member(1004, "김하성");
		
		memberArrayList.addMember(memberLee);
		memberArrayList.addMember(memberRuy);
		memberArrayList.addMember(memberChoi);
		memberArrayList.addMember(memberKim);
		
		memberArrayList.showAllMember();
		
		memberArrayList.removeMember(memberRuy.getMemberId());
		memberArrayList.showAllMember();
		
		
		}
	
	}

