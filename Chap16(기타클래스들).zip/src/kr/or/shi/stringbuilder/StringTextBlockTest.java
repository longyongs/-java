package kr.or.shi.stringbuilder;
//09.01 1-1 
//window properties 버전 11->16으로 변경
//pakage에서 properties -> java bulid path에서 jdk버전을 16으로 변경하면 이런식으로 사용 가능
//public class StringTextBlockTest {

//	public static void main(String[] args) {
//		String textBlocks = """					
//				Hello,
//				hi,
//				how r u
//				""";
//		System.out.println(textBlocks);
//		System.out.println(getBlockOfHtml());
//
//	}
//	
//	public static String getBlockOfHtml() {//메인에서 호출하기 위해서 static 메서드
//		return """
//				<html>
//					<body>
//						<span>sample test</span>
//					</body>
//				</html>
//				""";
		
//	}
//}