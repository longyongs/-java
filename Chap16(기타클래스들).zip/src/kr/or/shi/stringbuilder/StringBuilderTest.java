package kr.or.shi.stringbuilder;
//09.01 1-3

public class StringBuilderTest {

	public static void main(String[] args) {
		StringBuilder builder = new StringBuilder("java");
		System.out.println(builder);
		System.out.println(System.identityHashCode(builder));
		
		builder.append(" kotlin");
		System.out.println(builder);
		System.out.println(System.identityHashCode(builder));	//
		
	}
}
