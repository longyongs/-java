package kr.or.shi.exception02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

//09.06 10-1

public class FileExceptionHandlingTest {
	
	public static void main(String[] args) {
		
		FileInputStream fis = null;						//FileInpubStream은 리소스이다. 메모리를 사용하니깐 scanner처럼 close해야함.
		
		// 예외처리 try_catch
		try {
			fis = new FileInputStream("a.txt");
			
		} catch (FileNotFoundException e) {
			//e.printStackTrace();						//디버깅용, 어디서 오류가 발생한지 찾아줌.
			System.out.println(e.getMessage());
			return;
		} finally {										//예외 발생해도 무조건 실행.
			if(fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("finally 구문은 항상 호출된다.");
			
		}
		System.out.println("end");
	}
	
}
