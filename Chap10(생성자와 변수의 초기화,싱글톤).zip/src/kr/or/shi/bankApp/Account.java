package kr.or.shi.bankApp;
//15-1
public class Account {
	
	private String ano;						//계좌번호 account number
	private String owner;					//계좌주
	private int balance;					//잔액
	
	//매개변수가 있는 생성자
	public Account(String ano, String owner, int balance) { //source -> generate constructor field에서 생성
		this.ano = ano;				//this는 생성자에서 또 다른 생성자를 생성할때 사용
		this.owner = owner;
		this.balance = balance;
	}

	
	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	

}
