package kr.or.shi.initiallize;
//12
public class Product {
	
	static int number = 0;			//접근지정자 타입 변수, 공유목적
	int countNo;					//인스턴스별 개별생성, default값 할당해서 초기화 안해도됨.
	int[] arr = new int[10];
	
	
	//인스턴스 초기화 블럭
	{		
		System.out.println("인스턴스 초기화 블럭 호출됨");
		++number;											//전위증감연산사 
		this.countNo = Product.number;
		
		//복잡한 초기화같은 경우는 초기화 블럭 실행문에서 작성하면 가독성이 좋아짐.
		for(int i=0; i<arr.length; i++) {
			this.arr[i] = (int)(Math.random()*10) + 1;
		}
	}
	
	//정적 초기화 블럭 (단, 한번만 실행됨)
	static {
		System.out.println("정적 초기화 블럭 호출됨.");
	}
	
	//기본 생성자
	public Product() {
		System.out.println("기본생성자 호출됨");
	}
	
	
}
