package kr.or.shi.initiallize;
//11
public class BlockTest {
	
	//인스턴스 초기화블럭 : 인스턴스 생성될때 마다 호출됨 (heap)
	{
		System.out.println("인스턴스 초기화블럭 실행됨");
	}
	
	//정적 초기화블럭 : 단 한번 수행이 이루어짐 (class area에 생성)
	static {
		System.out.println("정적 초기화블럭 실행됨");
	}
	
	public BlockTest() {		//기본 생성자
		System.out.println("생성자 호출됨");
	}
	
	public static void main(String[] args) {
		BlockTest blocktest = new BlockTest();
		
	}
}
