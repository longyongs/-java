package kr.or.shi.polymorphism02;
//3-2

//자손클래스
public class SportCar extends Car{

	public void speedUp() {
		System.out.println("속도를 올립니다.");
	}
	
}
