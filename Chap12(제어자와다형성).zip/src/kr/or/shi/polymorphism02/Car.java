package kr.or.shi.polymorphism02;
//3-1

//조상클래스
public class Car {

	String color;
	int door;
	
	public void drive() {
		System.out.println("차가 달립니다.");
	}
	
	public void stop() {
		System.out.println("차가 멈춥니다");
	}
}
