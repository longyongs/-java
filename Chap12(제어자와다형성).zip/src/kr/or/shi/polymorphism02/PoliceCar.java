package kr.or.shi.polymorphism02;
//3-3

//자손클래스
public class PoliceCar extends Car{
	
	public void siren() {
		System.out.println("사이렌을 울립니다.");
	}
}
