package kr.or.shi.polymorphism02;
//3-4

public class CarTest {

	public static void main(String[] args) {
		Car car = null;
		SportCar sportCar = new SportCar();
		PoliceCar policeCar = new PoliceCar();
		
		sportCar.speedUp();
		
		
		car = sportCar;					//1.업캐스팅 (자손 -> 조상 타입) : 조작할 수 있는 멤버가 줄어듬. -> car. 했을때 car.speedup을 못쓴다. car = (Car) sportCar; 자동형변환이라 생략가능
		//car.speedUp();
		
		SportCar sportCar2 = null;
		sportCar2 = (SportCar) car;		//2.다운캐스팅 (조상 -> 자손) : 조작할 수 있는 멤버가 늘어난다. -> sportCar2.speedUp();이 가능해짐.
										//다운캐스팅을 할때, 반드시 명시적으로 형변환 코드를 작성해야함.
		sportCar2.speedUp();
		
		//sportCar = policeCar;			//3.서로 관련없는 클래스들간의 형변환 : 서로 상속관계가 아니기 때문에 
										// 형변환이 이루어질 수 없음.
		
		
	}

}
