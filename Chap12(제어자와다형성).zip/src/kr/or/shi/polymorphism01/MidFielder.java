package kr.or.shi.polymorphism01;
//2-3

// pass속성 추가
public class MidFielder extends Player{
	
	private int pass;
 
	
	
	public MidFielder(String name, int age, int backNumber, int speed, int pass) {
		super(name, age, backNumber, speed);
		this.pass = pass;
	}
	
	public int getPass() {
		return this.pass;
	}
	
	
	@Override
	public void info() {
		super.info();
		System.out.println("유효 패스 : " + this.getPass());
	}
	
}

