package kr.or.shi.modifier01;
//1-1
/*
 * 접근 제한자(access modifier)의 가시성
 * -------------------------------------------------------------------
 * 				외부 클래스			하위 클래스			동일 패지키			내부 클래스
 *----------------------------------------------------------------------
 *  public		  o					o				o				o	
 *----------------------------------------------------------------------
 *	protected	  x					o				o				o	
 *----------------------------------------------------------------------
 *	선언되지 않음
 *	(default)	  x					x				o				o
 *----------------------------------------------------------------------
 *	private		  x					x				x				x
 *----------------------------------------------------------------------
 */
public class Phone {
	
	//접근제어자 protected : 같은 패키지, 상속한 경우에 접근가능.(상속받지 않은 클래스도 같은 패키지에서는 접근 가능)
	//					  다른 패키지에서 접근 불가.
	public String model;
	private String color;
	private String company;
	
	public Phone() {			//기본 생성자
		
		
	}

	public Phone(String model, String color, String company) {
		super();												//조상 클래스의 기본생성자 호출
		this.model = model;
		this.color = color;
		this.company = company;
	}
	
	
	//getter()
	public String getModel() {
		return model;
	}

	public String getColor() {
		return color;
	}

	public String getCompany() {
		return company;
	}
	
	@Override
	public String toString() {
		String str = "모델 : " + this.getModel() + 
						", 색상 : " + this.getColor() + 
						", 제조회사 : " + this.getCompany();
		return str;
		 
	}
	
	
	
}
