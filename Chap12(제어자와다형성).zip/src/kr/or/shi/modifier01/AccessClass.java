package kr.or.shi.modifier01;
//1-2
public class AccessClass extends Phone {

	Phone phone = new Phone("갤럭시 Z 폴드3", "black", "SAMSUNG");
	
	public void method() {
		System.out.println(phone.model);
	}
	
}
