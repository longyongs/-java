package kr.or.shi.polymorphism03;
//8.26 1-4
public class Audio extends Product{
	
	public Audio() {	//기본생성자
		super(100);
	}
	
	@Override
	public String toString() {
		return "Audio";
	}
}
