package kr.or.shi.polymorphism03;
//8.26 1-5
public class Apple {

}
