package kr.or.shi.polymorphism03;
//8.26 1-3
public class Computer extends Product{

	public Computer() {
		super(200);
	}
	
	@Override
	public String toString() {
		return "Computer";
	}
}
