package kr.or.shi.abstract02;
//2-2

public abstract class KakaoSender extends ContentSender {
	private String content;
	
	//생성자는 기본생성자가 없어서 맞춰줌
	public KakaoSender(String title, String name, String content) {
		super(title, name);
		this.content = content;
	}

	@Override
	public void sendMessage(String content) {
		
	} 

}
