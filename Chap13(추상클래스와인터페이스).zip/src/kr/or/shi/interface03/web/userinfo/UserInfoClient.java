package kr.or.shi.interface03.web.userinfo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import kr.or.shi.interface03.domain.userinfo.UserInfo;
import kr.or.shi.interface03.domain.userinfo.dao.UserInfoDao;
import kr.or.shi.interface03.domain.userinfo.dao.mssql.UserInfoMsSqlDao;
import kr.or.shi.interface03.domain.userinfo.dao.mysql.UserInfoMySqlDao;
import kr.or.shi.interface03.domain.userinfo.dao.oracle.UserInfoOracleDao;

public class UserInfoClient {
	
	public static void main(String[] args) throws IOException {
		
		FileInputStream fStream = new FileInputStream("db.properties");
		
		Properties properties = new Properties();
		properties.load(fStream);
		
		String dbType = properties.getProperty("DBTYPE");
	
		UserInfo userInfo = new UserInfo();
		userInfo.setUserID("sct");
		userInfo.setPassword("1216");
		userInfo.setUserName("Lee");
		
		UserInfoDao userInfoDao = null;						//다형성 적용
		
		if(dbType.equals("MYSQL")) {
			userInfoDao = new UserInfoMySqlDao();
		}
		else if(dbType.equals("ORACLE")) {
			userInfoDao = new UserInfoOracleDao();
		}
		else if(dbType.equals("MSSQL")) {
			userInfoDao = new UserInfoMsSqlDao();
		}
		else {
			System.out.println("db error");
			return;
		}
			
		userInfoDao.insertUserInfo(userInfo);
		userInfoDao.updateUserInfo(userInfo);
		userInfoDao.deleteUserInfo(userInfo);
	}
	
}
