package kr.or.shi.interface03.domain.userinfo.dao.mssql;

import kr.or.shi.interface03.domain.userinfo.UserInfo;
import kr.or.shi.interface03.domain.userinfo.dao.UserInfoDao;

public class UserInfoMsSqlDao implements UserInfoDao {

	@Override
	public void insertUserInfo(UserInfo userInfo) {
		System.out.println("Insert into MsSql DB userID = " + userInfo.getUserID());
	}

	@Override
	public void updateUserInfo(UserInfo userInfo) {
		System.out.println("update into MsSql DB userID = " + userInfo.getUserID());
	}

	@Override
	public void deleteUserInfo(UserInfo userInfo) {
		System.out.println("delete into MsSql DB userID = " + userInfo.getUserID());
	}

}
