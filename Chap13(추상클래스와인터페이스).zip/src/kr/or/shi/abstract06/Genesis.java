package kr.or.shi.abstract06;
//6-5
public class Genesis extends Car{

	@Override
	public void drive() {
		System.out.println("Genesis 달립니다");	

	}

	@Override
	public void stop() {
		System.out.println("Genesis 멈춥니다");			
	}

}
