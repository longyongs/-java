package kr.or.shi.abstract06;
//6-4
public class Grandeur extends Car{

	@Override
	public void drive() {
		System.out.println("Grandeur 달립니다");	
		
	}

	@Override
	public void stop() {
		System.out.println("Grandeur 멈춥니다");
		
	}

}
