package kr.or.shi.abstract06;
//6-2
public class Sonata extends Car {

	@Override
	public void drive() {
		System.out.println("Sonata 달립니다");	
	}

	@Override
	public void stop() {
		System.out.println("Sonata 멈춥니다");	
	}

}
