package kr.or.shi.abstract06;
//6-3
public class Avante extends Car{

	@Override
	public void drive() {
		System.out.println("Avante 달립니다");	
	}

	@Override
	public void stop() {
		System.out.println("Avante 멈춥니다");	
	}

}
