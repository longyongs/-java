package kr.or.shi.abstract06;
//6-6

public class CarTest {

	public static void main(String[] args) {
		Car sonata = new Sonata();
		sonata.run();
		System.out.println("================================================");
		
		Car grandeur = new Grandeur();
		grandeur.run();
		System.out.println("================================================");

		Car avante = new Avante();
		avante.run();
		System.out.println("================================================");

		Car genesis = new Genesis();
		genesis.run();
		System.out.println("================================================");

		
		
	}

}


