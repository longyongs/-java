package kr.or.shi.abstract05;
//2-4

public class CarTest {

	public static void main(String[] args) {
		Car aiCar = new AICar();
		aiCar.run();
		
		System.out.println();
		
		Car mCar = new ManualCar();
		mCar.run();
	}

}
