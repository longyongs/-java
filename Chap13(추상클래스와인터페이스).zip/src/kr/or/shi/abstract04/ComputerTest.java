package kr.or.shi.abstract04;
//1-5
//프레임워크 : 구조화된 SW인데 활용하면 그걸도입해서 구현할수있음
public class ComputerTest {
	public static void main(String[] args) {
		Computer desktop = new Desktop();
		desktop.display();
		
		Computer noteBook = new MyNoteBook();
		noteBook.typing();
		
	}
	
	
}

