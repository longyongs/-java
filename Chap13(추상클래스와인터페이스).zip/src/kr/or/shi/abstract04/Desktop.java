package kr.or.shi.abstract04;
//08.27 1-2

public class Desktop extends Computer {

	@Override
	public void display() {
		System.out.println("Desktop display");
	}

	@Override
	public void typing() {
		System.out.println("Desktop typing");
 
	}
	
	@Override
	public void turnOff() {
		super.turnOff();
	}


}
