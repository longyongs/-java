package kr.or.shi.abstract04;
//1-3

public abstract class NoteBook extends Computer{
	
	@Override
	public void display() {
		System.out.println("NoteBook display");
		
	}
}
