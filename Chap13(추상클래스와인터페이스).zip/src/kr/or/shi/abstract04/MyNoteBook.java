package kr.or.shi.abstract04;
//1-4
public class MyNoteBook extends NoteBook {
	
	@Override
	public void typing() {
		System.out.println("MyNoteBook typing");
	}
}
