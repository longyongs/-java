package kr.or.shi.interface05.case03;
//4-1 
//선입선출  -->
public interface Queue {
	void enQueue(String title);
	String deQueue();
	
	int getSize();
}
