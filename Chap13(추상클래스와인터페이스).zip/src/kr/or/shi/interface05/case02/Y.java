package kr.or.shi.interface05.case02;
//3-2
public interface Y {
	void y();
}
