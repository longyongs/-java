package kr.or.shi.interface05.case02;
//3-3
public interface MyInterface extends X, Y {
	void myMethod();
}
