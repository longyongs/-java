package kr.or.shi.interface05.case02;
//3-5
public class MyInterfaceTest {
	public static void main(String[] args) {
	
		MyClass myClass = new MyClass();
		
		//원래 선언했던 급
		X xClass = myClass;						//upcasting 
		xClass.x();
		
		Y yClass = myClass;						//upcasting
		yClass.y();
		
		//다 호출 가능 
		MyClass iClass = myClass;
		iClass.x();
		iClass.y();
		iClass.myMethod();
	}
}
