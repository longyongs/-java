package kr.or.shi.interface05.case01;
//08.30 2-1
public interface Buy {

	void buy(); 										//생성자
	
	default void order() {
		System.out.println("구매 주문합니다.");
	}
	
}
