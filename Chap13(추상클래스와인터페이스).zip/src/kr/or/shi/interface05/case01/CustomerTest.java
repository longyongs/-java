package kr.or.shi.interface05.case01;
//2-4

public class CustomerTest {

	public static void main(String[] args) {
		Customer customer = new Customer();
		customer.buy();
		customer.sell();
		customer.order();
		customer.sayHello();
		
		System.out.println();
		
		//다형성 적용
		Buy buyer = customer;				//upcasting 자동형변환, 부모타입으로만 보임(자식타입인 sayheello 안보임
		buyer.buy();
		buyer.order();
		
		System.out.println();
		
		Sell seller = customer;				//upcasting 자동형변환 적용, seller를 상속받아서 다형성
		seller.sell();						//인터페이스 복수개를 implements 한 경우
		seller.order();
		
		
	}

}
 