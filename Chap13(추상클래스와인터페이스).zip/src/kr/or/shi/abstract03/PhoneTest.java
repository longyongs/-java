package kr.or.shi.abstract03;
//3-4
public class PhoneTest {
	
	public static void main(String[] args) {
		
		SmartPhone smartPhone = new SmartPhone(20210826, "SAMSUNG", "이재용");
		smartPhone.showInfo();
		smartPhone.turnOn();
		smartPhone.turnOff();
		smartPhone.internetSearch();
		
		System.out.println("----------------------------------------------");
		
		PoldablePhone poldablePhone = new PoldablePhone(20210901, "samsung", "최지만");
		poldablePhone.showInfo();
		poldablePhone.turnOn();
		poldablePhone.turnOff();
		poldablePhone.foldOn();
		poldablePhone.foldOff();
		
		System.out.println("----------------------------------------------");

		//배열에서 다형성을 사용함.
		Phone[] phones = new Phone[10];
		phones[0] = new SmartPhone(20211001, "Apple", "추신수");
		phones[1] = new PoldablePhone(20211101, "샤오미", "박지성");
		
		
		phones[0].turnOn();															//phones의 오버라이딩된 것만 가능함
		phones[0].turnOff();
		
		phones[1].showInfo();
		
	}
}
