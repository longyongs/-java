package kr.or.shi.school;
import java.util.ArrayList;
//21.09.09 1-5


public class School {
	private static School instance = new School();
	private School() {}
	public static School getInstance() {
		if(instance == null)
			instance = new School();
		return instance;
	}
	
	
	private ArrayList<Student> students = new ArrayList<>();
	private ArrayList<Subject> subjects = new ArrayList<>();

	public void addStudent(Student student) {
		students.add(student);
	}
	
	public void addSubject(Subject subject) {
		subjects.add(subject);
	}
	
	public ArrayList<Student> getStudents() {
		return students;
	}
	public ArrayList<Subject> getSubjects() {
		return subjects;
	}
	
	

	
}
