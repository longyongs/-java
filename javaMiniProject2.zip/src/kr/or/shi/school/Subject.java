package kr.or.shi.school;
//21.09.09 1-4

import java.util.ArrayList;

import kr.or.shi.utils.Constant;

public class Subject {
	private int subjectId;				//과목 고유번호
	private String subjectName;			//과목 이름
	private int gradeType;				//학점 부여 방식(기본은 A~F 방식)
	private ArrayList<Student> students = new ArrayList<>();	//과목을 수강 신청한 학생들
	
	//생성자 추가 source -> Generic Construct using field
	public Subject(int subjectId, String subjectName) {
		this.subjectId = subjectId;
		this.subjectName = subjectName;
		this.gradeType = Constant.AB_TYPE;
	}
	
	//수강신청하는 메서드
	public void register(Student student) {			// 수강신청
		students.add(student);
	}

	//getter 추가
	public int getSubjectId() {
		return subjectId;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public int getGradeType() {
		return gradeType;
	}

	public ArrayList<Student> getStudents() {
		return students;
	}

	
	
	
	
}
