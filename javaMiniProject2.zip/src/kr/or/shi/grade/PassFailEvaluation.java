package kr.or.shi.grade;

public class PassFailEvaluation implements GradeEvaluation {
	
	public PassFailEvaluation() {
		
	}
	
	//add method
	@Override
	public String getGrade(int score) {

		String grade;		//지역변수라 초기화 안됨.
		
		if (score >= 70)
			grade = "Pass";

		else
			grade = "Fail";
		
		return grade;
	}



}