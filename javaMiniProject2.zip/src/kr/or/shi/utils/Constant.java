package kr.or.shi.utils;
//21.09.09 2-1

public class Constant {
	
	public static final int AB_TYPE = 0;			//A,B,C,D,F 학점
	public static final int SAB_TYPE = 1;			//S,A,B,C,D,F 학점
	public static final int PF_TYPE = 2;			//추가함/ Pass,Fail 학점
	
	
	public static final int OPERATING_SYSTEM = 1001;		//운영체제
	public static final int MATH = 1002;
	public static final int GOLF = 1003;
	
}
