package kr.or.shi.string;
//3-4
/*
 * 문자열을 잘라내는 메서드
 */
public class SubstringTest {

	public static void main(String[] args) {
		String phonenum = "01012347890";
		
		String str1 = phonenum.substring(3);
		System.out.println(str1);
		
		//마지막 인덱스는 미포함 = n-1
		String str2 = phonenum.substring(0, 3);
		System.out.println(str2);

	}
}
