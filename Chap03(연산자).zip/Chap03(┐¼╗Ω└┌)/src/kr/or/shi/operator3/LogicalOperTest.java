package kr.or.shi.operator3;

public class LogicalOperTest {

	public static void main(String[] args) {
		// 논리연산자 ( && , || )

		
		boolean result = false;
		int i = 10;
		char ch = 'b';
		
		result = (i > 5);
		System.out.println("(i > 5) : " + result);
		
		result = (i >= 9) && (i < -8);		// 둘다 T일떄, T 
		System.out.println("(i >= 9) && (i < -8) : " + result);
		
		result = (i >= 9) || (i < -8); 		// 둘중 하나이상 T일떄, T 
		System.out.println("(i >= 9) || (i < -8) : " + result);
		
		//알파벳 소문자인지 확인하는 식
		result = (ch > 'a' && ch < 'z');
		System.out.println("(ch > 'a' && ch < 'z') : " + result);
		
		//ch에 저장되어진 값이 알파벳인지 확인하는 조건
		// 알파벳 : true (결과)
		result = (ch > 'a' && ch < 'z') || (ch > 'A' && ch < 'Z');
		System.out.println("ch값이 알파벳 : " + result);
		
		//범위를 비교할때에는 값 <= 변수 <= 값 식으로 쓸 수 없다.
		//왼쪽에서 오른쪽으로 실행이 됨.
		//'a' < 'b' < 'z'
		//----------- true or false 
 
		
	}

}
