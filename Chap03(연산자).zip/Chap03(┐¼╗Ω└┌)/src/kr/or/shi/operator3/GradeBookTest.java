package kr.or.shi.operator3;

import java.util.Scanner;

/*
 * 사용자로부터
 * 번호, 이름, 국어, 영어, 수학 점수순으로 입력받아서(nextint로 받고,)
 * 다음과 같은 양식대로 출력되게 프로그램을 작성하시오.
 * 
 * 번호 : 3
 * 이름 : 류현진
 * 국어 : 80
 * 영어 : 79
 * 수학 : 80
 * 번호 : 003번 이름: 류현진
 * 국어 : 080점(3자리) 영어: 079점 수학: 080점
 * 총점 : 239점 평균: 079.67점 (전체6자리.소수점이하 2자리
 */
public class GradeBookTest {
	
	
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("번호 입력 : ");
		int number = scan.nextInt();
		
		System.out.print("이름 입력 : ");
		scan.nextLine();   					// 의미 없는 값을 한번 넣어야함
		String name = scan.nextLine();
		
		System.out.print("국어 입력 : ");
		int talk = scan.nextInt();
		
		System.out.print("영어 입력 : ");        
		int english = scan.nextInt();
		
		System.out.print("수학 입력 : ");
		int math = scan.nextInt();
		
		
		int result1 = talk+english+math;	
		double result2 = (talk+english+math)/3;	
		
		System.out.printf("번호 : %03d\n", number);
		System.out.printf("이름 : %s\n", name);
		System.out.printf("국어 : %03d\n", talk);
		System.out.printf("영어 : %03d\n", english);
		System.out.printf("수학 : %03d\n", math);
		System.out.printf("총점 : %03d\n", result1 );
		System.out.printf("평균점 : %03.2f\n", result2);
		
		scan.close();
	}

}
