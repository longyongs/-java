package kr.or.shi.operator3;

public class StringEqualsTest {

	public static void main(String[] args) {
		// 참조형 타입의 ==, !=에 대해서 이해할 수 있다.
		
		/*
		 * 문자열을 리터럴로 할당 												[ 저장소 ]
		 * 리터럴인 경우에는 같은 값이 있는지 체크해서, 먼저 메모리공간(heap)을			|static|
		 * 확인하고 나서 같은 값이 있다면 같은 주소를 공유하게 되고						|stack | -> ( str1(값:대구) str2(값:대구))
		 * 없다면 새로운 곳에 인스턴스(객체)를 생성해준다.							|heap  | -> ( 주소100번지(값: 대구광역시))
		 *                                                              결론 : str1,2가 변수를 리터럴로 선언해서 '대구광역시'라는 같은 값이있어서 값은 주소번지를 공유;
		 */
		
		String str1 = "대구광역시";		//문자열, new 대신 리터럴(값) 할당도 가능
		//String str2 = "자바";
		String str2 = "대구광역시";		// 리터럴(값) 자체를 넣어서  
		
		// 참조형 타입에서 ==은 '주소비교'를 하고 있음.
		boolean result = (str1 == str2);
		System.out.println("str1 == str2 : " + result);		// 참조주소번지 /= 참조주소번지, 주소번지 비교해서 같지 않다.
	
		
		/*
		 * 																[ 저장소 ]
		 * 																|static|
		 * 																|stack | -> ( str1(값:대구, 100번지) str3(값:대구, 200번지))
		 * 																|heap  | -> ( 주소100번지(값: 대구광역시), 주소200번지(값: 대구광역시)
		 * 																결론 : str1,2가 변수를 리터럴로 선언해서 '대구광역시'라는 같은 값이있어서 값은 주소번지를 공유;
		 */
		// new 연산자를 사용해서 객체생성시 새로운 인스턴스(객체)가 생성됨.
		String str3 = new String("대구광역시");
		result = (str1 == str3);
		System.out.println("str1 == str3 : " + result);		// 문자열을 new 연산자를 통해서 만들면 새로운 주소번지에 생성을 해서 주소번지의 차이가 난다.
		
		/*
		 * String 클래스의 equals() 매소드는 주소와 상관없이 '값'이 같다면, 
		 * 무조건 true를 리턴함.
		 */
		result = str1.equals(str2); 			// .equals는 주소번지가 가지고있는 값을 비교함.
		System.out.println("str1.equals(str2) : " + result);
		
		result = str1.equals(str3);
		System.out.println("str1.equals(str3) : " + result);
		
		
	}

}
