package kr.or.shi.operator3;
/*
 * 사용자로부터
 * 번호, 이름, 국어, 영어, 수학 점수순으로 입력받아서(nextint로 받고,)
 * 다음과 같은 양식대로 출력되게 프로그램을 작성하시오.
 * 
 * 번호 : 3
 * 이름 : 류현진
 * 국어 : 80
 * 영어 : 79
 * 수학 : 80
 * 번호 : 003번 이름: 류현진
 * 국어 : 080점(3자리) 영어: 079점 수학: 080점
 * 총점 : 239점 평균: 079.67점 (전체6자리.소수점이하 2자리
 */

//교수님 풀이
import java.util.Scanner;

public class GradeBookTest2 {
	
	static final int SUBJECT_SIZE = 3;
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("번호 : ");
		int id = scan.nextInt();
		
		System.out.print("이름 : ");
		scan.nextLine();   					// 의미 없는 값을 한번 넣어야함
		String name = scan.nextLine();
		
		System.out.print("국어 : ");
		int korean = scan.nextInt();
		
		System.out.print("영어 : ");        
		int english = scan.nextInt();
		
		System.out.print("수학 : ");
		int math = scan.nextInt();
		
		
		int sum = korean + english + math;	
		double average = sum / (double)SUBJECT_SIZE;	//sum은 int라서 타입을 맞출려면 Subsize를 강제 캐스팅
		
		System.out.printf("번호 : %03d 이름 : %s\n" , id, name);
		System.out.printf("국어 : %03d 영어 : %03d 수학 : %03d\n", korean, english, math);
		System.out.printf("총점 : %03d 평균점 : %06.2f\n", sum, average);
		
		scan.close();
	}

}
