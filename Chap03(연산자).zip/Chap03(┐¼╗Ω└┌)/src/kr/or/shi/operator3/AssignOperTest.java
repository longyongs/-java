package kr.or.shi.operator3;

public class AssignOperTest {

	public static void main(String[] args) {
		// 복합대입연산자
		
		int result = 0;
		
		result += 10;		// result = result + 10
		System.out.println("result : " + result);
		
		result -= 5;		// result = 10 - 5 = 5
		System.out.println("result : " + result);
		
		result *= 5;		// result = 5 * 5 = 25
		System.out.println("result : " + result);
		
		result /= 5;		// result = 25 / 5 = 5
		System.out.println("result : " + result);
		
		result %= 5;		// result = 5 % 5 = 1...0(나머지)
		System.out.println("result : " + result);
	}

}
