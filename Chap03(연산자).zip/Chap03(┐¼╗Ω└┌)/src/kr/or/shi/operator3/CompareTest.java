package kr.or.shi.operator3;
/*
 * 입력 받은 두 수중 큰 수를 출력하시오.
 * 
 * 입력1 : 90
 * 입력2 : 89
 * 90
 */

import java.util.Scanner;

public class CompareTest {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("숫자 2개 입력 : ");
		
		int num;					// 변수 초기화
		int num1 = scan.nextInt();
		int num2 = scan.nextInt();
		

		num = (num1 > num2) ? num1 : num2;
		System.out.printf("큰 숫자 : [%d]\n", + num);
		
		
		scan.close();
	}
}
