package kr.or.shi.method;
//5
/*
 * 반환 값이 없고 받는 인자값이 2개 있는 덧셈 메서드를 구현하시오.
 */
public class Method02 {
	
	public static void plusMetho(int a, int b) {
		System.out.printf("인자로 넘겨받은 2개의 값은 %d와 %d입니다.\n", a, b);
		
		//연산 
		int result = a + b;
		System.out.println("두 수를 더한 값은 = " + result);
	}
	
	public static void main(String[] args) {
		// 메서드가 받는 인자값이 있다는 것은 호출부에서 파라미터 값을 넘긴다는 의미임.
		int a = 100, b = 200;
		plusMetho(a, b);
		
	}

}
