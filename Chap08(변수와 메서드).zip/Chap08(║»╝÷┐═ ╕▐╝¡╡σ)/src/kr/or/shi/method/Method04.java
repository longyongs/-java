package kr.or.shi.method;
//7
/*
 * 반환값이 있고 받는 인자값이 있는 대문자 출력 메서드를 구현하시오.
 * 
 */

public class Method04 {
	
	public static String CapitalMethod(String str) {
		String result = str.toUpperCase();						// 소->대문자 변경
		return result;
	}
	
	public static void main(String[] args) {
		String result = CapitalMethod("korea");
		System.out.println("입력한 소문자의 대문자는 = " + result);
	}

}
