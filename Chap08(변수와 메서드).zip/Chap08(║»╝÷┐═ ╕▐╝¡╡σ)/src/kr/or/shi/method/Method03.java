package kr.or.shi.method;
//6
/*
 * 반환값이 있고 받는 인자값이 없는 메서드를 구현하시오.
 */

public class Method03 {
	
	public static int returnMethod() {
		int result = 100;
		result *= 100;
		return result;
	}
	
	public static void main(String[] args) {
		int result = returnMethod();
		System.out.println("메서드 호출에 따른 리턴된 값은 = " + result);
	}

}
 