package kr.or.shi.staticmethod;
	
public class Calculator {
//8
	//인스턴스 메서드
	//인스턴스 메서드의 특징 : new 연산자로 인스턴스를 생성하고 참조변수명.인스턴스 메서드명 접근가능.
	public int add(int x, int y) {
		double dResult = Calculator.divide(10.5, 11.7);
		System.out.println("인스턴스 메서드내에서 static 메서드 호출 : " + dResult);
		return x + y;
	}
	//인스턴스 메서드
	public int substract(int x, int y) {
		return x - y;
	}
		//정적(static) 메서드
		//static 메서드의 특징 : 인스턴스 생성없이 클래스명.정적메서드명으로 바로 접근이 가능함.
		public static long multiply(long x, long y) {
			/*
			 * static 메서드는 이미 메모리 상단에 올라가 있고 인스턴스 생성없이 접근이 가능해야하는데, 
			 * 인스턴스가 생성이되어야지만 사용가능한 add()가 왔기때문에 예외가 발생한 것임.
			 * 즉, 인스턴스가 언제 생성될지 아무도 모르기때문에 
			 * static 메서드 안에는 인스턴스 메서드가 절대로 오면 안됨.
			 */
			//this.add(10,5);
			
			return x * y;
		}
		
		//static 메서드
		public static double divide(double x, double y) {
			return x / y;
		}
	}


