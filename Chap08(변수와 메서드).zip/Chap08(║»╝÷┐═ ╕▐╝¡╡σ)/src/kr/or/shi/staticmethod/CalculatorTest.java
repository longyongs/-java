package kr.or.shi.staticmethod;
//9
public class CalculatorTest {

	public static void main(String[] args) {
		Calculator cal = new Calculator();
		int addResult = cal.add(100, 200);
		System.out.println("인스턴스 메서드 add() 호출 결과 : " + addResult);
		
		//static 호출
		long mulResult = Calculator.multiply(100, 20);
		System.out.println("static 메서드 multyply() 호출 결과 : " + mulResult);
		
		double divResult = Calculator.divide(10.2, 10.2);
		System.out.println("static 메서드 multyply() 호출 결과 : " + divResult);
		
		//정적메서드 예(선언부에 static 제어자가 붙어있음)
		Integer.parseInt("100");
		Math.random();
		
		
	}

}
