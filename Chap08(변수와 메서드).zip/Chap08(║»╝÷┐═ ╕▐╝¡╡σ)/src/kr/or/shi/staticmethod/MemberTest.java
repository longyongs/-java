package kr.or.shi.staticmethod;
//11
public class MemberTest {

	public static void main(String[] args) {
		Member.sMethod();		//클래스명.정적멤버명
		Member.cv = 500;
		Member.sMethod();
		
		//인스턴스 멤버들을 사용하기 위해서는 반드시 new라는 연산자가 힙에다
		//인스턴스를 만들어야 사용이 가능함.
		Member member = new Member();
		member.iMethod();
		member.iv = 999;
		member.iMethod();
	}

}
