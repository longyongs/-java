package kr.or.shi.staticmethod;
//10
public class Member {
	
	int iv = 100;			//인스턴스 멤버변수
	static int cv = 200;	//static 멤버변수
	
	//인스턴스 메서드
	public void iMethod() {
		System.out.println("iv : " + this.iv);
		//System.out.println("cv : " + Member.cv); 
	}
	
	//static 메서드
	public static void sMethod {
		//이유는 언제 인스턴스가 만들어질지 아무도 모르기 때문임.
		//System.out.println("iv : " + this.iv);
	
		
		//cv는 static 변수이기 때문에 인스턴스 없이도 접근가능해야하는데.
		//static 메서드내에서는 접근 가능함.
		System.out.println("cv : " + Member.cv);
	}
	
}

