package kr.or.shi.review;
/*
여러 개의 수가 정렬된 순서로 있을 때 특정한 수를 찾아보세요.
단순 반복문을 이용하면 수의 개수에 따라 비교 횟수가 증가하는 수행이 이루어집니다.
수가 정렬된 상태에서는 이진 탐색(binary search)을 활용하면 매번 비교되는 요소의 수가 절반으로 감소될 수 있으므로 원하는 수를 찾을 수 있습니다.

정렬된 수 : [12, 23, 31, 49, 54, 66, 70, 87, 95, 108]

54의 위치를 찾아보세요
99의 위치를 찾아보세요

[힌트]
수가 정렬된 상태이므로 중간의 값을 하나 선택합니다.
찾으려는 값이 그보다 크면 범위를 오른쪽으로 그보다 작으면 범위를 왼쪽으로 좁힐수 있습니다.
한번 비교 할때 마다 1/2씩 범위가 좁혀집니다.

// SearchTest.java

[출력예시]
찾는 수는 5번째 있습니다.

찾는 수가 없습니다.
*/
public class SearchTest {

	public static void main(String[] args) {
		 
		int[] numbers = {12, 23, 31, 49, 54, 66, 70, 87, 95, 108};
		
		int target = 95;
		
		int left = 0;						//low
		int right = numbers.length-1; 		//high
		int mid = (left + right)/2;			//middle
		
		int temp = numbers[mid];
		boolean find = false;
		
		while(left <= right) {				//아직 비교할 숫자들이 남아있다면
			if(target == temp) {			//수를 찾은 경우(일치하면 탐색성공)
				find = true;
				break;
			}
			else if(target < temp) {			//찾으려는 수가 중간원소보다 더 작은 경우
				right = mid-1;					//찾으려는 값이 그보다 작으면 범위를 왼쪽으로 좁힐 수 있음.		
			}
			else {								//찾으려는 값이 중간원소보다 크면 범위를 오른쪽으로 좁힐 수 있음.		
				left = mid+1;
			}
			mid = (left + right)/2;				//중간요소 결정
			temp = numbers[mid];
		}
		
		if(find==true) {
			mid++;
			System.out.println("찾는 수는" + mid + "번째 있습니다.");
		}
		else {
			System.out.println("찾는 수가 없습니다.");
		}
		
	}
}
