package kr.or.shi.review;

import java.util.Scanner;

	//사용자 입력을 받아 2차원 배열을 생성하고 값을 입력하는 코드를 구현하시오.
	//이때, 중첩 반복문을 사용하여 출력도 같이 해보시오.
	//TwoArrayUserInputTest.java
	/*
	[출력예시]
	행의 갯수를 입력하고 [Enter] 치세요 = 3
	열의 갯수를 입력하고 [Enter] 치세요 = 5
	1번째 행에 입력할 문자 5개를 차례대로 입력하고 [Enter] 치세요 = Korea  (charAt활용)
	2번째 행에 입력할 문자 5개를 차례대로 입력하고 [Enter] 치세요 = China  
	3번째 행에 입력할 문자 5개를 차례대로 입력하고 [Enter] 치세요 = Ameri
	Korea (0,0)~(0,4)
	China
	Ameri (2,1)~(2,4)
	*/
public class TwoArrayUserInputTest {
	
	public static void main(String[] args) {
		
		
		Scanner scan = new Scanner(System.in);
		
		//2차원 배열의 행과 열을 선언 
		System.out.print("행의 갯수를 입력하고 [Enter] 치세요 = ");
		int row = scan.nextInt(); 
		System.out.print("열의 갯수를 입력하고 [Enter] 치세요 = ");
		int colum = scan.nextInt();
		scan.nextLine();
		
		//char[][] 배열 선언
		char[][] array = new char[row][colum];
		
		//사용자 입력을 받아서 저장할 String[] 선언 -- 크기를 row로 해줘야함.
		String str;
		
		//2차원 배열 요소 -- 사용자가 입력하는 값으로 셋팅
		for(int i=0; i<array.length; i++) {															//for(int i=0; i<row; i++)
			System.out.printf("%d번째 행에 입력할 문자 %d개를 차례대로 입력하고 [Enter] 치세요 = ", i+1, colum);
			str = scan.nextLine();				//int 다음에 string을 입력받을 경우 int값에서 enter받은걸 초기화. nexLine은 엔터까지 추가 .
		
			for(int j=0; j<array[i].length; j++) {
				array[i][j] = str.charAt(j);	
			}
		}
		
		for(int i=0; i<array.length; i++) {
			for(int j=0; j<array[i].length; j++) {
				System.out.print(array[i][j]);				
			}
			System.out.println();
		}
	} 
}