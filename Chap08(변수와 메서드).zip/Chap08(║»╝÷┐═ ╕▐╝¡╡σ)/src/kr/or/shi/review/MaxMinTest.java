package kr.or.shi.review;

import com.sun.java.util.jar.pack.ConstantPool.Index;

//랜덤으로 정수 10개의 값을 갖는 배열을 만들어 최댓값과 최솟값을 같이 출력해보시오.
//이때, 랜덤 정수 값은 0~99 사이로 한다.
//MaxMinTest.java

/*
[출력예시]

31 74 52 81 35 61 24 99 57 65
arr 배열내 최댓값 : 99
arr 배열내 최솟값 : 24
*/
/*
 * 해결하기
 * -- 배열에 있는 수중 맨처음에 있는 값을 max와 min으로 가정함.
 * 	  배열의 마지막 숫자까지 비교하면서 더 큰수나 더 작은 수가 나올때 max와 min의 값을 바꿔줌.
 * 	  그떄의 위치를 변수에 저장함.	
 */
public class MaxMinTest {

	public static void main(String[] args) {
		System.out.println();
		
			int max, min;
			int[] list = new int[10];
			

			
			for(int i=0; i<list.length; i++) {
				list[i] = (int)(Math.random()*100); 			// 1~99난수 발생
				System.out.printf("%d " , list[i]);
			}
			System.out.println();
			
			max = list[0]; 
			min = list[0];
			
			
			for(int i=0; i<list.length; i++) {
				if(max < list[i]) {
					max = list[i];
				}
				if(min > list[i]) {
					max = list[i];
				}
			}
			
			System.out.println("---------------------------------------------");
			System.out.println("arr 배열내 최댓값 : " + max);
			System.out.println("arr 배열내 최솟값 : " + min);
			System.out.println("---------------------------------------------");
	}
}


//				
//				System.out.println();
//				//정수 배열 선언
//				int[] arr = new int[10];
//				
//				//반복문을 실행해서 랜덤으로 10개 정수 값을 설정
//				for(int i=0; i<arr.length; i++) {
//					arr[i] = (int)(Math.random()*100); 			// 0~99난수 발생
//					System.out.print(arr[i] + " ");
//				}
//				System.out.println();
//				
//				//최대값, 최소값 변수 초기화
//				int max = arr[0], min = arr[0];
//				
//				//반복문 실행하면서 최대값, 최소값 비
//				for(int i=0; i<arr.length; i++) {
//						if(max < arr[i]) {
//							max = arr[i];
//						}
//						if(min > arr[i]) {
//							max = arr[i];
//						}
//					}
//					
//					//출력
//					System.out.println("---------------------------------------------");
//					System.out.println("arr 배열내 최댓값 : " + max);
//					System.out.println("arr 배열내 최솟값 : " + min);
//					System.out.println("---------------------------------------------");
//
//			}

				
				
			
	
