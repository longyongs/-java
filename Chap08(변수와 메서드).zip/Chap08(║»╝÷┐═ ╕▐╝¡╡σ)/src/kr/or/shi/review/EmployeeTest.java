package kr.or.shi.review;

public class EmployeeTest {

	public static void main(String[] args) {
		
		Employee employeeWon = new Employee(); //생성자
		employeeWon.setEmployeeName("장원규");
		//System.out.println(Employee.serialNum);
		
		Employee employeeSa = new Employee(); // 객체 생성
		employeeSa.setEmployeeName("사공승조");
		//Employee.serialNum++;
		
//		System.out.println(employeeWon.serialNum);
//		System.out.println(employeeSa.serialNum);
		System.out.println(employeeWon.getEmployeeName() +", "+ employeeWon.getEmployeeId());
		System.out.println(employeeSa.getEmployeeName() +", "+ employeeSa .getEmployeeId());
		
	}

}
