package kr.or.shi.review;

import java.util.Arrays;

/*
여러 개의 수가 배열에 있을 때 그 중 가장 큰 값과 가장 작은 값을 찾으세요.
배열의 몇 번째에 있는지 순서를 찾으세요.
반복문을 한번만 사용하여 문제를 해결하세요.
수 : [10, 55, 2, 23, 79, 16, 82, 101, 30, 45]

// MinMaxTest.java
 
[출력]
가장 큰 값은 101이고, 위치는 7번째 입니다.
가장 작은 값은 2이고, 위치는 4번째 입니다.

*/

public class MaxMinTest2 {
	
	public static void main(String[] args) {
		
		int[] arr = new int[] {10, 55, 2, 23, 79, 16, 82, 101, 30, 45};
		int max = arr[0];
		int min = arr[0];
		
		for(int i=0; i<arr.length; i++) {
			if(max < arr[i]) {
				max = arr[i];
				int a = max;
				
			}
			if(min > arr[i]) {
				max = arr[i];
				int b = min;
			}
		}
		
		int a = max;
		int b = min;
		
		System.out.printf("가장 큰 값은" +max+ "이고, 위치는" + a + "번째 입니다.\n");
		System.out.printf("가장 작은 값은" +min+ "이고, 위치는" + b +"번째 입니다.");

		
	}
}

