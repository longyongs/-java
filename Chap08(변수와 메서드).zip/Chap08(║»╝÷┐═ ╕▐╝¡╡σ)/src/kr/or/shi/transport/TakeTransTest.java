package kr.or.shi.transport;

/*
 * 이준형님의 남은 돈은 10000원 입니다.
 * 한상헌님의 남은 돈은 15000원 입니다.
 * 609 버스의 승객은 1명이고, 수입은 1400원 입니다.
 * 2호선 지하철 승객은 1명이고, 수입은 1200원 입니다.
 */
public class TakeTransTest {

	public static void main(String[] args) {

		Student lee = new Student("이준형", 10000);
		Student han = new Student("한상헌", 15000);
		
		System.out.println(lee);
		System.out.println(han);
		
		Bus bus609 = new Bus(609);
		Subway subwayBlue = new Subway(2);
		
		lee.takeBus(bus609);
		lee.takeSubway(subwayBlue);
		han.takeSubway(subwayBlue);
		
		System.out.println(bus609);
		System.out.println(subwayBlue);
		
		System.out.println(lee);
		System.out.println(han);
	}
}



