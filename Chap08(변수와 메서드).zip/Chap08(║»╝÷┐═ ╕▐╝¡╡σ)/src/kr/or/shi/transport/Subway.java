package kr.or.shi.transport;
//19
/*
 * 버스(지하철) 타고 SCT로 가는 학생의 과정을 OOP 구현하시오.
 * 
 */
public class Subway {
	
	int lineNumber;
	int passengerCount;
	int money;
	
	public Subway(int lineNumber) {
		this.lineNumber = lineNumber;	
	}
	
	public void take(int money) {			//승차
		this.money += money;
		passengerCount++;
	}
	
	@Override
	public String toString() {
		return lineNumber +"번의 지하철의 승객은 " +
				passengerCount + "명 이고, 수입은 " +
				money + "원 입니다.";
	}
}
