package kr.or.shi.lamda03;
//09.06 3-1

@FunctionalInterface
public interface MyInterface {
	void method();
	
}
