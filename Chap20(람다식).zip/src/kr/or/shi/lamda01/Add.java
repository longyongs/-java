package kr.or.shi.lamda01;
//09.06 1-1

@FunctionalInterface 	//복수개의 메서드가 정의 안되게 설정
public interface Add {
	public int add(int x, int y);
//	public int multiple(int x, int y);
}
