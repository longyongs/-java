package kr.or.shi.lamda01;
//1-2
public class AddTest {
	public static void main(String[] args) {
		
//		Add addObj = (x, y) -> { return x + y; };		//add() 구현
		Add addObj = (x, y) -> x + y; 		//add라는 abstract 메서드를 람다식으로 정의, 명령문이 하나인 경우 중괄호와 return문 생략 가능 
		
		System.out.println(addObj.add(2, 3));			//add() 호출 
	}
}
