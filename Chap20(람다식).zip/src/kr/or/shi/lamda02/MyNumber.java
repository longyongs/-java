package kr.or.shi.lamda02;
//09.06 2-1

@FunctionalInterface		//복수개의 메서드가 정의 안되게 설정
public interface MyNumber {
	int getMax(int num1, int num2);
}
 