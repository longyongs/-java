package kr.or.shi.lamda02;
//2-2
public class MyNumberTest {
	
	public static void main(String[] args) {
		MyNumber myNumber = (num1, num2)  -> num1 > num2 ? num1 : num2;			//한개일때 중괄호 생략 가능, n1.n2 비교후 참이면 앞 거짓이면 뒤
		
		System.out.println(myNumber.getMax(10, 20));
		
	}
}
