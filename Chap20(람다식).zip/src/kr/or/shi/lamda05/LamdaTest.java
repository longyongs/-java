package kr.or.shi.lamda05;
//5-2
//교수님 : 람다식은 안드로이드 ui 딴에서 사용하고 있다고함
// Collection : 객체를 저장
//     vs
// stream - IO     
//		  - Lamda

public class LamdaTest {
	
	public static void main(String[] args) {
		
		MyInterface myInterface = null;
		
		myInterface = (x, y) -> {
			int result = x + y;
			return result;
		};
		int result = myInterface.method(100, 200);
		System.out.println("매개변수 2개와 리턴값 있는 람다식의 값 : " + result);
		
		myInterface = (x, y) -> {return x + y;};
		result = myInterface.method(300, 200);
		System.out.println("매개변수 2개와 리턴값 있는 람다식의 값 : " + result);
		
		myInterface = (x, y) -> x + y;
		result = myInterface.method(1000, 200);
		System.out.println("매개변수 2개와 리턴값 있는 람다식의 값 : " + result);
	
		myInterface = (x, y) -> add(x, y);	//구현체 부분에서 또 다른 메서드 호출
		result = myInterface.method(700, 200);
		System.out.println("매개변수 2개와 리턴값 있는 람다식의 값 : " + result);
	
	}
	
	public static int add(int x, int y) {
		return x + y;
	}
}
