package kr.or.shi.lamda05;
//09.06 5-1

@FunctionalInterface
public interface MyInterface {
	int method(int x, int y);			//2개의 매개변수와 리턴값이 존재하는 추상메서드
}
