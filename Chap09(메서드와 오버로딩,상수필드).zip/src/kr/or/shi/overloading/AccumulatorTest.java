package kr.or.shi.overloading;
//3
class A {
	int data1 = 10;
	int data2 = 20;
}

public class AccumulatorTest {

	public static void main(String[] args) {
		//(메서드) 오버로딩 : 매개변수의 갯수,타입 등..이 다를때 적용
		Accumulator accum = new Accumulator();		//객체 만듦
		int iResult = accum.add(10, 50);
		System.out.println("iResult : " + iResult);

		long lResult = accum.add(100, 7500L);
		System.out.println("lResult : " + lResult);

		double dResult = accum.add(107.88, 11.55);	//double은 오차가 발생함.
		System.out.println("dResult : " + dResult);

		long arrResult = accum.add(new int[] {1,2,3,4,5});			//참조변수
		System.out.println("arrResult : " + arrResult);

		iResult = accum.add(new A());
		System.out.println("iResult : " + iResult);

	}

}
