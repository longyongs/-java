package kr.or.shi.finalconstant;
//5
public class PersonTest {

	public static void main(String[] args) {
		
		Person person = new Person(30);
		
		//final 속성은 상수이므로 값을 변경 절대 못함.
//		person.NATION = "China";	//(불가함)final은 한번 할당하고 나서 재할당이 안된다
//		person.AGE = "China";	//재할당이 안된다
	
		System.out.println(person);
		
		System.out.println(Person.MAX_NUMBER);
		
		Person person0 = new Person(50);
		Person person2 = new Person(150);
		Person person3 = new Person(250);
		
		System.out.println(person0);
		System.out.println(person2);
		System.out.println(person3);
		System.out.println();
		
		System.out.println(person0.AGE);
		System.out.println(person2.AGE);
		System.out.println(person3.AGE); 
		
		double d = Math.PI;
		
	}

}
