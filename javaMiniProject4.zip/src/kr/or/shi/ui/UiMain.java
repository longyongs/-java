package kr.or.shi.ui;
//21.09.09 4-1

import kr.or.shi.institution.Country;
import kr.or.shi.institution.Institution;
import kr.or.shi.institution.Meet;
import kr.or.shi.institution.Score;
import kr.or.shi.institution.view.GenerateGradeReport;
import kr.or.shi.utils.Constant;

public class UiMain {
	
	Institution mInst = Institution.getInstance();
	Country usa;
	Country kr;
	Country others;
	GenerateGradeReport gradeReport = new GenerateGradeReport();
	
	public static void main(String[] args) {
		
		UiMain uiMain = new UiMain();		//생성자
		
		uiMain.createCountry();
		uiMain.createMeet();
		
		String report = uiMain.gradeReport.getReport();
		System.out.println(report);
	}

	private void createMeet() {
		usa = new Country(Constant.USA, "미국산");
		kr = new Country(Constant.KR, "국산");
		others = new Country(Constant.Others, "독일/칠레/아르헨티나산");
		
		others.setGradeType(Constant.PF_TYPE);
		
		mInst.addCountry(usa);
		mInst.addCountry(kr);
		mInst.addCountry(others);
	}

	private void createCountry() {
		Meet meet1 = new Meet(20210910, "LA갈비", usa);
		Meet meet2 = new Meet(20210911, "텍사스안심", usa);
		Meet meet3 = new Meet(20210912, "미국삼겹살", usa);
		Meet meet4 = new Meet(20210913, "안동갈비", kr);
		Meet meet5 = new Meet(20210914, "수원왕갈비", kr);
		Meet meet6 = new Meet(20210915, "국산안심", kr);
		Meet meet7 = new Meet(20210916, "국산등심", kr);
		Meet meet8 = new Meet(20210917, "칠레가브리살", others);
		Meet meet9 = new Meet(20210918, "독일갈비살", others);
		Meet meet10 = new Meet(20210918, "아르헨티나항정살", others);
		
		mInst.addMeet(meet1);
		mInst.addMeet(meet2);
		mInst.addMeet(meet3);
		mInst.addMeet(meet4);
		mInst.addMeet(meet5);
		mInst.addMeet(meet6);
		mInst.addMeet(meet7);
		mInst.addMeet(meet8);
		mInst.addMeet(meet9);
		mInst.addMeet(meet10);

		usa.register(meet1);
		usa.register(meet2);
		usa.register(meet3);
		usa.register(meet4);
		usa.register(meet5);
		usa.register(meet6);
		usa.register(meet7);
		usa.register(meet8);
		usa.register(meet9);
		usa.register(meet10);
		
		kr.register(meet1);
		kr.register(meet2);
		kr.register(meet3);
		kr.register(meet4);
		kr.register(meet5);
		kr.register(meet6);
		kr.register(meet7);
		kr.register(meet8);
		kr.register(meet9);
		kr.register(meet10);
		
		others.register(meet8);
		others.register(meet9);
		others.register(meet10);
		
		this.addScoreForStudent(meet1, usa, 90);
		this.addScoreForStudent(meet2, usa, 82);
		this.addScoreForStudent(meet3, usa, 55);
		
		this.addScoreForStudent(meet4, kr, 100);
		this.addScoreForStudent(meet5, kr, 60);
		this.addScoreForStudent(meet6, kr, 90);
		this.addScoreForStudent(meet7, kr, 80);

		this.addScoreForStudent(meet8, others, 80);
		this.addScoreForStudent(meet9, others, 50);
		this.addScoreForStudent(meet10, others, 100);
		
		
		
	}
	
	//과목별 성적 입력
	public void addScoreForStudent(Meet meet, Country country, int score) {
		
		Score score1 = new Score(meet.getMeetId(), country, score);
		meet.addCountryScore(score1);
	}
	
	
}
		
	