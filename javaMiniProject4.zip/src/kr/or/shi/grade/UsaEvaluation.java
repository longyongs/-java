package kr.or.shi.grade;

public class UsaEvaluation implements GradeEvaluation {
	
	
	public UsaEvaluation() {}
	
	
	//add method
	@Override
	public String getGrade(int score) {
		
		String grade;
		
		if (score >= 90 && score <=100)
			grade = "Prime";					//프라임 등급
		else if (score >= 80 && score <=89)
			grade = "Choice";						//초이스 등급
		else if (score >= 70 && score <=79)
			grade = "Select";						//셀렉트 등급
		else if (score >= 60 && score <=69)
			grade = "Standard";					//스탠다드 등급
		else
			grade = "non-selling";				//판매불가
		
		
		return grade;
	}
	
	
}