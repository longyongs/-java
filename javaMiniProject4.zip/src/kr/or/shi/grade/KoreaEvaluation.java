package kr.or.shi.grade;

//국산 고기 등급에 대한 클래스
public class KoreaEvaluation implements GradeEvaluation {
	
	public KoreaEvaluation() {}
	
	//add method
	@Override
	public String getGrade(int score) {

		String grade;		//지역변수라 초기화 안됨.
		
		//고기등급
		if (score >= 95 && score <=100)
			grade = "1++";
		else if (score >= 90 && score <=94)
			grade = "1+";
		else if (score >= 80 && score <=89)
			grade = "1";
		else if (score >= 70 && score <=79)
			grade = "2";
		else if (score >= 60 && score <=69)
			grade = "3";
		else
			grade = "non-selling";
		
		return grade;
	}



}
