package kr.or.shi.institution;
//1-4
import java.util.ArrayList;

import kr.or.shi.utils.Constant;

public class Country {
	private int countryId;		//원산지 고유번호
	private String countryName; //원산지 이름
	private int gradeType;		//고기 등급 부여방식(기본은 1+++~3 방식)
	private ArrayList<Meet> meets = new ArrayList<>();		//축산평가를 받는 고기들
	
	//생성자 추가
	public Country(int countryId, String countryName) {
		super();
		this.countryId = countryId;
		this.countryName = countryName;
		this.gradeType = Constant.KR_TYPE;
	}

	//평가받는고기들이 오는 메서드
	public void register(Meet meet) {	//고기불러오기
		meets.add(meet);
	}

	public int getCountryId() {
		return countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public int getGradeType() {
		return gradeType;
	}

	
	public void setGradeType(int gradeType) {
		this.gradeType = gradeType;
	}

	public ArrayList<Meet> getMeets() {
		return meets;
	}
	
	
	
	
	
}
