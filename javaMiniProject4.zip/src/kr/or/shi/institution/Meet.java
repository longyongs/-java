package kr.or.shi.institution;
//1-2
import java.util.ArrayList;

public class Meet {
	
	private int meetId;				//고기번호
	private String meetName;		//고기이름
	private Country countryOrigin; 	//고기원산지(미국,한국) 
	private ArrayList<Score> scores = new ArrayList<>();	//고기의 등급점수 리스트
	
	//생성자 추기
	public Meet(int meetId, String meetName, Country countryOrigin) {
		this.meetId = meetId;
		this.meetName = meetName;
		this.countryOrigin = countryOrigin;
	}
	
	public void addCountryScore(Score score) {
		scores.add(score);
	}
	
	//getter
	public int getMeetId() {
		return meetId;
	}

	public String getMeetName() {
		return meetName;
	}

	public Country getCountryOrigin() {
		return countryOrigin;
	}

	public ArrayList<Score> getScores() {
		return scores;
	}
	
	
	
	
}
