package kr.or.shi.institution.view;
//21.09.09 5-1


import java.util.ArrayList;

import kr.or.shi.grade.GradeEvaluation;
import kr.or.shi.grade.KoreaEvaluation;
import kr.or.shi.grade.PassFailEvaluation;
import kr.or.shi.grade.UsaEvaluation;
import kr.or.shi.institution.Country;
import kr.or.shi.institution.Institution;
import kr.or.shi.institution.Meet;
import kr.or.shi.institution.Score;
import kr.or.shi.utils.Constant;

public class GenerateGradeReport {
	
	Institution institution = Institution.getInstance();
	public static final String TITLE = " 축산된 고기 등급  >> \t\t\n";
	public static final String HEADER = "고기 품명  \t  |  고기 품번  |  원산지  \t  | 평가점수  \n"	;
	public static final String LINE = "---------------------------------------------\n";
	public static final String LINE2 = "=============================================\n";
	
	private StringBuffer buffer = new StringBuffer();
	
	public String getReport() {
		ArrayList<Country> countrys = institution.getCountrys();
		for(Country country : countrys) {	//향상된 for문
			makeHeader(country);
			makeBody(country);
			makeFooter();
		}
		
		return buffer.toString();
	}
	
	public void makeFooter() {
		buffer.append("\n");
	}

	public void makeHeader(Country country) {
		buffer.append("\t" + country.getCountryName());	//고기품명 추가
		buffer.append(GenerateGradeReport.TITLE);
		buffer.append(GenerateGradeReport.HEADER);
		buffer.append(GenerateGradeReport.LINE2);
	}
	
	//학생별 해당과목 학점 계산
	private void makeBody(Country country) {
		ArrayList<Meet> meets = country.getMeets();
		for(int i=0; i<meets.size(); i++) {
			Meet meet = meets.get(i);	
			buffer.append(meet.getMeetName());
			buffer.append(" | ");
			buffer.append(meet.getMeetId());
			buffer.append(" | ");
			buffer.append(meet.getCountryOrigin().getCountryName() + "\t");
			buffer.append(" | ");
			GetScoreGrade(meet, country);
			buffer.append("\n");
			buffer.append(LINE);			//'======'출력
			
		}
		
	}
	
	//고기별 해당원산지 등급 계산
	public void GetScoreGrade(Meet meet, Country country) {
		ArrayList<Score> scores = meet.getScores();
		int krId = meet.getCountryOrigin().getCountryId();
		
		//학점 평가 클래스들 
		GradeEvaluation[] gradeEvaluations = 
			{new KoreaEvaluation(), new UsaEvaluation(), new PassFailEvaluation()};
		
		//학생이 가진 점수들
		for(int i=0; i<scores.size(); i++) {
			Score score = scores.get(i);
			if(score.getCountry().getCountryId() == country.getCountryId()) {
				String grade;
				
				if (score.getCountry().getCountryId() == krId) {
					grade = gradeEvaluations[Constant.KR_TYPE].getGrade(score.getScore());
				}
				else if(score.getCountry().getCountryId() != krId && score.getCountry().getCountryId() == 1003 )
					grade = gradeEvaluations[Constant.PF_TYPE].getGrade(score.getScore());
				else
					grade = gradeEvaluations[Constant.USA_TYPE].getGrade(score.getScore());		//전공과목이 아닌 학점 평가
				
				
								
				buffer.append(score.getScore());
				buffer.append(" : ");
				buffer.append(grade);
				buffer.append(" | ");
			
			}
		}
	}
	
	
}

 