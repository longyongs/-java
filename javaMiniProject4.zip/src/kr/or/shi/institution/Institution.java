package kr.or.shi.institution;
//1-5
import java.util.ArrayList;

public class Institution {
	private static Institution instance = new Institution();
	private Institution() {}
	
	public static Institution getInstance() {
		if(instance == null)
			instance = new Institution();
		return instance;
	}

	private ArrayList<Meet> meets = new ArrayList<>();
	private ArrayList<Country> countrys = new ArrayList<>();

	public void addMeet(Meet meet) {
		meets.add(meet);
	}
	
	public void addCountry(Country country) {
		countrys.add(country);
	}
	
	public ArrayList<Meet> getMeets() {
		return meets;
	}

	public ArrayList<Country> getCountrys() {
		return countrys;
	}
	
	
}
