package kr.or.shi.institution;
//1-3
public class Score {
	
	private int meetId;			//고기번호
	private Country country;	//고기원산지
	private int score; 			//고기평가점수
	
	//생성자 
	public Score(int meetId, Country country, int score) {
		this.meetId = meetId;
		this.country = country;
		this.score = score;
	}

	//값을 확인하기위해 getter
	public int getMeetId() {
		return meetId;
	}

	public Country getCountry() {
		return country;
	}

	public int getScore() {
		return score;
	}
	
	
	
	
}
