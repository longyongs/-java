package kr.or.shi.utils;
//21.09.09 2-1

public class Constant {
	
	public static final int USA_TYPE = 0;			// 프라임,초이스,셀렉트,스탠다드
	public static final int KR_TYPE = 1;			//1++,1+,1,2,3, 등외 등급
	public static final int PF_TYPE = 2;			//등외 등급
	
	
	
	public static final int KR = 1001;			//국산
	public static final int USA = 1002;			//미국산
	public static final int Others = 1003;		//다른나라산
	
}
