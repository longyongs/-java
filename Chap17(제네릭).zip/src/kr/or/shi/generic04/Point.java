package kr.or.shi.generic04;
//6-2
public class Point<T, V> {
	
	T x;	//참조변수
	V y;
	
	Point(T x, V y) {		//오버로드된 생성자 (초기화)
		this.x = x;
		this.y = y;
	}
	
	public T getX() {
		return x;
	}
	
	public V getY() {
		return y;
	}
	
	
}
