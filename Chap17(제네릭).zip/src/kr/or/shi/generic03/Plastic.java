package kr.or.shi.generic03;
//09.01 5-2

public class Plastic extends Material {

	@Override
	public String toString() {
		return "재료는 Plastic입니다.";
	}

	@Override
	public void doPrint() {
		// TODO Auto-generated method stub
		
	}
}
