package kr.or.shi.generic03;
//5-4
public abstract class Material {
	
	public abstract void doPrint();
	

}
