package kr.or.shi.generic03;
//09.01 5-3

public class Powder extends Material {
	
	@Override
	public String toString() {

		return "재료는 Powder입니다.";
	}

	@Override
	public void doPrint() {
		// TODO Auto-generated method stub
		
	}
}
