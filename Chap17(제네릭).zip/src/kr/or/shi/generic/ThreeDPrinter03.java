package kr.or.shi.generic;
//09.01 3-6

public class ThreeDPrinter03 {
	
	private Object material;

	
	public Object getMaterial() {
		return material;
	}

	public void setMaterial(Object material) {
		this.material = material;
	}
	
	
	
}
