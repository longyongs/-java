package kr.or.shi.generic;
//09.01 3-5

public class ThreeDPrinter02 {

	private Plastic material;

	public Plastic getMaterial() {
		return material;
	}

	public void setMaterial(Plastic material) {
		this.material = material;
	}
	
	
	
	
}
