package kr.or.shi.generic;
//09.01 3-2

public class Powder {
	
	@Override
	public String toString() {

		return "재료는 Powder입니다.";
	}
}
