package kr.or.shi.generic;
//09.01 3-3 

public class Plastic {

	@Override
	public String toString() {
		return "재료는 Plastic입니다.";
	}
}
