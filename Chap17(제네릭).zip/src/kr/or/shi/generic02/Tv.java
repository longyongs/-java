package kr.or.shi.generic02;
//09.01 4-1

public class Tv<E> {

	private E e;

	public E getE() {
		return e;
	}

	public void setE(E e) {
		this.e = e;
	}
	
	
}
