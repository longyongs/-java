package kr.or.shi.generic02;
//4-2
public class TvTest {
	
	public static void main(String[] args) {
		
	
	
	Tv<String> tv = new Tv<>();
	tv.setE("LG OLED TV");
	String tvname = tv.getE();

	System.out.println("나의 TV는 " + tvname + "입니다.");

	}
}