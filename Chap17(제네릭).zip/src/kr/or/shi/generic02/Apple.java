package kr.or.shi.generic02;
//4-4

public class Apple {

	@Override
	public String toString() {
		return "사과";
	}
}
