package kr.or.shi.equals;
//08.31 1-1
public class ObjectEqualsTest {

	public static void main(String[] args) {
		Object object1 = new Object();				//위아래는 서로 다른 주소 번지를 가짐
		Object object2 = new Object();				//
		
		//Object클래스의 equals() : 메모리번지 비교
		boolean result1 = object1.equals(object2);
		System.out.println("equals() : " + result1);
		
		boolean result2 = (object1 == object2);
		System.out.println("== 연산자 : " + result1);

	}
}
