package kr.or.shi.equals;
//08.31 1-2
import java.util.Arrays;

public class Student {
	int age;
	String name;
	int[] subject;
	
	public Student(int age, String name, int[] subject) {
		this.age = age;
		this.name = name;
		this.subject = subject;
	}
	
	@Override
	public boolean equals(Object obj) { 	//object 클래스 == 최상위 클래스라 어떤거든 다 가능
		
		if(obj instanceof Student) {
			Student student = (Student)obj;		//Downcasting
			//논리적 동등을 위한 조건 설정
			if( (this.age == student.age) && (this.name == student.name) && (Arrays.equals(this.subject, student.subject)) ) {	
				return true;
			}
		}
		
		return false;
	}
	
}
