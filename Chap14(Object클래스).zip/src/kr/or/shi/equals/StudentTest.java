package kr.or.shi.equals;
//08.31 1-3
public class StudentTest {

	public static void main(String[] args) {
		
		int[] arr = new int[5];
		Student student1 = new Student(10, "최지만", new int[] {100, 90}) ; 
		Student student2 = new Student(10, "류현진", new int[] {100, 90});
		System.out.println(student1.equals(student2));

		Student student3 = new Student(10, "류현진", new int[] {100, 90}) ; 
		Student student4 = new Student(10, "류현진", new int[] {100, 90});
		System.out.println(student3.equals(student4));
//		Student student3 = new Student(10, "최지만", arr);
//		Student student4 = new Student(10, "최지만", arr);
//		System.out.println(student3.equals(student4));
//
//		Student student5 = new Student(10, "최지만", arr);
//		Student student6 = new Student(30, "최지만", arr);
//		System.out.println(student5.equals(student6));

	}
}
