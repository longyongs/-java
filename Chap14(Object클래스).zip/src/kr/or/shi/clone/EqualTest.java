package kr.or.shi.clone;
//08.31 2-2
public class EqualTest {
	
	public static void main(String[] args) throws CloneNotSupportedException {
		Student std1 = new Student(100, "Lee");
		Student std2 = new Student(100, "Lee");
		
		System.out.println(std1 == std2);
		System.out.println(std1.equals(std2));		//동일한 결과
		
		System.out.println(std1.hashCode());
		System.out.println(std2.hashCode());		//해쉬코드값(가상메모리주소) 위아래 다름
		
		System.out.println("================================");
		String str1 = new String("sct");
		String str2 = new String("sct");
		System.out.println(str1.equals(str2));		//String에서는 equals를 값으로 비교하게끔 오버라이드
		
		
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
		
		Integer integer = 100;										//원래는 new Integer(100); 
		System.out.println(integer.hashCode());						//오버라이드되어서 값 100
		//원래 hash 코드 값을 확인
		System.out.println(System.identityHashCode(integer));		

		
		System.out.println("=================clone()=================");
		System.out.println(std1); 									
		
		Student copyStudent = (Student) std1.clone();
		System.out.println(copyStudent);
		
		std1.setStudentName("Kim");
		copyStudent = (Student)std1.clone();
		
		System.out.println(str1);
		System.out.println(copyStudent);
		
		
	}
}
