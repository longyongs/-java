package kr.or.shi.loop4;

import java.util.Scanner;

/*
 * 무한루프를 이용한 프로그램이 바로 메뉴 프로그램이 된다.
 * 2. 출력
 * 아직 입력된 정보가 존재하지 않습니다.
 */

public class MenuTest {
	static final int ID_MIN = 1;
	static final int ID_MAX = 10;
	static final int SCORE_MIN = 0;
	static final int SCORE_MAX = 100;
	static final int SUBJECT_SIZE = 3;

	
	public static void main(String[] args) {
		
		
	Scanner scan = new Scanner(System.in);
	
	while(true) {
		System.out.println();
		System.out.println("==============================");
		System.out.println("	SCT대학교 성적관리 프로그램		");
		System.out.println("1.입력	2.출력	3.종료");
		System.out.println("==============================");	
		System.out.print("> ");
	
		
		int userChoice = scan.nextInt();
		
		if(userChoice == 1) {
			// 성적을 입력하는 코드를 여기에 구현 
			System.out.print("학생 번호 입력 : ");
			int id = scan.nextInt();
			
			while(!(id >= ID_MIN && id <= ID_MAX)) {
				//잘못된값 다시입력하라
				System.out.println("잘못 입력하였습니다(1~10).");
				System.out.print("번호 : ");
				id = scan.nextInt();
			}
			
			//학생 이름 입력
			System.out.print("이름 : ");
			scan.nextLine();   				// 오동작 방지를 위한 라인	
			String name = scan.nextLine();
			
			
			//국어 점수 입력
			System.out.print("국어 : ");
			int korean = scan.nextInt();
			while(!(korean >= SCORE_MIN && korean <= SCORE_MAX)) {
				System.out.println("잘못 입력하였습니다(1~100).");
				System.out.print("국어 : ");
				id = scan.nextInt();
			}
			
			// 영어 점수 입력
			System.out.print("영어 : ");
			int english = scan.nextInt();
			while(!(english >= SCORE_MIN && english <= SCORE_MAX)) {
				System.out.println("점수를 잘못 입력하였습니다(1~100).");
				System.out.print("영어 : ");
				english = scan.nextInt();
			}
			
			// 수학 점수 입력
			System.out.print("수학 : ");
			int math = scan.nextInt();
			while(!(math >= SCORE_MIN && math <= SCORE_MAX)) {
				System.out.println("점수를 잘못 입력하였습니다(1~100).");
				System.out.print("수학 : ");
				math = scan.nextInt();
			}
			
		}
		else if(userChoice == 2) {
			// 성적을 출력하는 코드를 여기에 구현
			int id = scan.nextInt();
			int name = scan.nextInt();
			int korean = scan.nextInt();
			int english = scan.nextInt();
			int math = scan.nextInt();
	
			int sum = korean + english + math;	
			double average = sum / (double)SUBJECT_SIZE;	//sum은 int라서 타입을 맞출려면 Subsize를 강제 캐스팅
			
			
			System.out.printf("번호 : %03d 이름 : %s\n" , id, name);
			System.out.printf("국어 : %03d 영어 : %03d 수학 : %03d\n", korean, english, math);
			System.out.printf("총점 : %03d 평균점 : %06.2f\n", sum, average);
		}
		
		else if(userChoice == 3) {
			System.out.println("사용해 주셔서 감사합니다.");
			break;
		}
	}
	
	
	
	scan.close();
	
	}

}
