package kr.or.shi.loop2;

/*
	*   *	x=5/y=1,5	3칸 
	 * *	x=2/y=3,4	1칸
	  *  	x=3/y=3
	 * * 	x=4/y=2,4 	 
	*   *   x=5/y=1,5
 */
public class XTest {

	public static void main(String[] args) {
		
		int x=1;
		int y=5;
		
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=5; j++) {
				//System.out.print("*");
				if(j == x || j == y) {
					System.out.print("*");
				}
				else {
					System.out.print(" ");
				}
			}
			System.out.println();
			x++;
			y--;
		
		
		}	
	}
}

