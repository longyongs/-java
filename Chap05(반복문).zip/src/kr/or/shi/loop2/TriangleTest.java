package kr.or.shi.loop2;

import java.util.Scanner;

//******** (8번 출력)
//*******
//*****
//****
//***
//**
//*

public class TriangleTest {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int x = 0;
		for(int i = 0; i<8; i++) {
			for(int j = 0; j<(8-x); j++) {
				System.out.print("*");
			}
			x++;
			System.out.println();
		}
		
		System.out.println("---------------------------------------");
		for(int i=1; i <= 8; i++) {
		    for(int j=1; j <=8-i; j++ ) {
		        System.out.print("*");
		    }
		    
		    System.out.println();
		}
		
	}

}
