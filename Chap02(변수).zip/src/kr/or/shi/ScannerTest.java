package kr.or.shi;

import java.util.Scanner;

public class ScannerTest {

	public static void main(String[] args) {
		
		
		/*
		 * ctrl + Shift + o : 자동임포트
		 * Scanner 클래스 : 입력을 받기 위한 클래스이고, 입력스트림임.
		 * 자원(Resource)은 사용하고 나서 반드시 닫아줘야함.
		 */ 
		
		
		Scanner scanner = new Scanner(System.in); // 객체 생성시 new 선언, 입력받을때 scannner
		
		
		
//		System.out.print("정수 한자리 입력 : ");
//		int num = scanner.nextInt();
//		System.out.println("사용자로부터 입력받은 숫자 : " + num);
//		
//		System.out.print("실수 한자리 입력 : ");
//		double dnum = scanner.nextDouble();
//		System.out.println("사용자로부터 입력받은 숫자 :" + dnum); // 스크롤 + ctrl + / = 주석
		
//		System.out.print("문자열을 입력 :");
//		/* 
//		 * next() : 공백을 기준으로 해서 문자를 입력 --> 단어를 입력시 사용.
//		 * nextLine() : 엔터키를 입력할때까지 문자열을 입력 --> 문장을 입력시 사용.
//		 */	
//		String str = scanner.nextLine();	// next할 경우는 스페이스 이후는 출력X
//		System.out.println("사용자로부터 입력받은 문자열 :" + str);
		
		
		System.out.print("문자열을 입력(숫자) :");
		int result = 100;
		String num2 = scanner.nextLine();
		
		int temp = Integer.parseInt(num2);
		
		int total = result + temp;
		System.out.println("연산결과 : " + total ); // result는 숫자 100, 문자열로 
		
		scanner.close();

	}

}
