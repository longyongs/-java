package kr.or.shi.object04;

public class TimeTest {

	public static void main(String[] args) {
		
		Time t1 = new Time();
		//t1.hour = 10; (private로 불가)
		
		System.out.println(t1.getHour());
		
		System.out.println(t1);
		System.out.println();
		
		//시를 설정
		t1.setHour(10);
		//분을 설정
		t1.setMinute(30);
		//초를 설정
		t1.setSecond(50);
		System.out.println(t1);
		System.out.println();
		
		t1.setHour(50);
		t1.setMinute(100);
		t1.setSecond(100);
		System.out.println(t1);
	}

}
