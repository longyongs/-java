package kr.or.shi.object05;

public class ipadTest {

	public static void main(String[] args) {
		
		Ipad ipad = new Ipad();
		ipad.setCompany("애플");
		ipad.setModel("iPadPro");
		ipad.setRelease(2021);
		ipad.setColor("골드");
		System.out.println(ipad.toString());
		
		Ipad ipad2 = new Ipad();
		ipad2.setCompany("삼성");
		ipad2.setModel("갤럭시탭S7");
		ipad2.setRelease(2020);
		ipad2.setColor("실버");
		System.out.println(ipad2.toString());
		
		
	}

}
