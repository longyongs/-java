package kr.or.shi.objectarray;
//3
public class ObjectCopy {
	
	public static void main(String[] args) {
		Book[] libray = new Book[5];
		Book[] copyLibray = new Book[5];
		
		libray[0] = new Book("태백산맥1", "조정래");
		libray[1] = new Book("태백산맥2", "조정래");
		libray[2] = new Book("태백산맥3", "조정래");
		libray[3] = new Book("태백산맥4", "조정래");
		libray[4] = new Book("태백산맥5", "조정래");
		
		System.arraycopy(libray, 0, copyLibray, 0, 5);
		
		libray[0].setTitle("인텔리제이IDEA");			
		libray[0].setAuthor("야마모토 유스케");
		
		for(Book book : libray) {
			book.showBookInfo();					//출력.
		}
		
		System.out.println("======================================");
		
		for(Book book : copyLibray) {
			book.showBookInfo();
		}
	}
	
}
