package kr.or.shi.object03;
//02번
public class MoniterTest {

	public static void main(String[] args) {
		
		//monitor참조변수는 리모컨과 같은 역할
		Monitor monitor = new Monitor();
		//System.out.println(monitor);
		monitor.power();
		monitor.power();
		monitor.power();
		
		monitor.channel = 5;
		monitor.channelUp();
		monitor.channelUp();
		
		monitor.channelDown();
		monitor.channelDown();
		
		monitor.volumeUp();
		monitor.volumeDown();
		
		System.out.println(monitor);
		monitor.power();
	}
}
