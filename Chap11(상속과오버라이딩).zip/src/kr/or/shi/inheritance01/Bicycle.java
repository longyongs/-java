package kr.or.shi.inheritance01;
//1-1
/*
 * 상속하는 클래스 : 상위 클래스, parent class, base class, super class
 * 상속받는 클래스 : 하위 클래스, child class, derived class, sub class
 * 자바는 single inheritance만 지원 함.
 */

//조상클래스
public class Bicycle {

	int id;
	String brand;
	String owner;
	
//	public void method() {
//		this.
//	}  //부모에서 자식 변수는 못가져옴.
}
