package kr.or.shi.inheritance01;
//1-2
/*
 * 상속을 하는 이유
 * 		1) 공통된 코드는 조상에서 관리
 * 		2) 개별적인 부분은 자손에서 따로 관리
 * 		3) 코드의 재사용성
 */

public class MountainBicyle extends Bicycle {
	
	//멤버 변수 : 5개
	String frame;
	int gear;
	int price;
	String tire;
		
	public void print() {
		System.out.println("id : " + this.id);
		System.out.println("brand : " + this.brand);
		System.out.println("frame : " + this.frame);
		System.out.println("gear : " + this.gear);
		System.out.println("price : " + this.price);
		System.out.println("price : " + this.owner);
	}
	
	public static void main(String[] args) {
		MountainBicyle mBicyle = new MountainBicyle();
		mBicyle.id = 1216;
		mBicyle.brand = "LESPO";
		mBicyle.frame = "알루미늄";
		mBicyle.gear = 33;
		mBicyle.price = 300000;
		mBicyle.owner = "류현진";
		
		mBicyle.print();
		
	}
}
