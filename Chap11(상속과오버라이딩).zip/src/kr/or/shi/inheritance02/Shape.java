package kr.or.shi.inheritance02;
//2-1
//조상클래스
public class Shape {
	String color = "black";
	public void draw() {
		System.out.println("draw()");
	}
}
